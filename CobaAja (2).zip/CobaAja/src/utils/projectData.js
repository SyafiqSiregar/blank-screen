export const projects = [
    {
        icon: '📷',
        title: 'RetinaCCTV Website',
        theme: 'tech',
        tags: ['Landing Page', 'WordPress', 'UI/UX'],
        desc: 'Company profile untuk perusahaan jasa instalasi CCTV & security system.',
        fullDesc: 'Website company profile CV. RetinaCCTV dirancang dengan pendekatan UI/UX untuk menghadirkan tampilan modern, responsif, dan user-friendly. Navigasi sederhana, struktur konten yang jelas, serta CTA yang strategis mempermudah calon klien menemukan informasi layanan dan portofolio dengan cepat. Fokus desain ini bertujuan meningkatkan pengalaman pengguna sekaligus memperkuat identitas brand perusahaan.',
        image: '/src/assets/images/projects/adsa.png',
        thumbnail: '/src/assets/images/projects/logoRetina.webp',
        useContain: true,
        liveUrl: 'https://retinacctv.id',
        role: 'UI/UX Designer & Web Developer',
        client: 'CV. RetinaCCTV',
        year: '2024',
        techStack: ['WordPress', 'Elementor', 'CSS', 'UI/UX Design'],
        features: [
            { icon: '🎨', title: 'Desain Modern & Responsif', desc: 'Tampilan profesional dengan dark theme yang elegan, responsif di semua perangkat.' },
            { icon: '📱', title: 'Mobile-Friendly', desc: 'Layout yang optimal di mobile, memudahkan calon klien mengakses dari smartphone.' },
            { icon: '💬', title: 'CTA ke WhatsApp', desc: 'Tombol CTA strategis yang langsung mengarahkan pengunjung ke WhatsApp untuk konsultasi.' },
            { icon: '💰', title: 'Pricing Packages', desc: 'Paket harga transparan: WiFi Camera (Rp 800rb), Analog (Rp 2.5jt), dan IP Camera (Rp 3.5jt).' },
            { icon: '👥', title: 'Team Showcase', desc: 'Profil tim ahli yang membangun kepercayaan klien terhadap profesionalitas perusahaan.' },
            { icon: '⭐', title: 'Testimonial Section', desc: 'Ulasan klien nyata yang memperkuat kredibilitas dan social proof perusahaan.' },
        ],
        sections: [
            {
                type: 'grid-cards',
                badge: 'LAYANAN KAMI',
                title: 'Layanan yang Ditampilkan',
                cards: [
                    { icon: '🔧', color: '#00cec9', title: 'Instalasi CCTV', desc: 'Pemasangan profesional untuk area indoor & outdoor.' },
                    { icon: '📦', color: '#fd79a8', title: 'Penjualan Perangkat', desc: 'DVR/NVR, kamera, kabel, dan aksesoris pendukung.' },
                    { icon: '🛠️', color: '#6c5ce7', title: 'Pemeliharaan & Servis', desc: 'Perawatan rutin, troubleshooting, dan perbaikan.' },
                    { icon: '📋', color: '#a29bfe', title: 'Konsultasi & Survey Lokasi', desc: 'Layanan konsultasi gratis untuk solusi pengawasan terbaik.' },
                ]
            },
            {
                type: 'grid-cards',
                title: 'Pendekatan Desain',
                cards: [
                    { icon: '🧭', color: '#0984e3', title: 'Navigasi Intuitif', desc: 'Navigasi sederhana untuk memudahkan pencarian informasi.' },
                    { icon: '📐', color: '#6c5ce7', title: 'Hierarki Visual', desc: 'Struktur konten yang jelas dengan hierarki visual yang kuat.' },
                    { icon: '👆', color: '#00cec9', title: 'CTA Strategis', desc: 'Penempatan tombol aksi yang optimal untuk mendorong konversi.' },
                    { icon: '🖼️', color: '#fd79a8', title: 'Showcase Portofolio', desc: 'Galeri instalasi untuk membangun kepercayaan klien.' },
                    { icon: '📝', color: '#e17055', title: 'Edukasi & SEO', desc: 'Artikel CCTV untuk edukasi pengunjung dan performa SEO.' },
                ]
            },
        ],
        results: [
            'Meningkatkan online presence dan identitas brand RetinaCCTV',
            'Memudahkan calon klien menemukan informasi layanan dan portofolio',
            'Menyediakan channel konversi langsung melalui integrasi WhatsApp',
            'Memperkuat kepercayaan klien melalui testimonial dan profil tim',
        ],
    },
    {
        icon: '💻',
        title: 'RetinaCCTV Pro System',
        theme: 'tech',
        tags: ['Web App', 'Inventory', 'POS'],
        desc: 'Sistem manajemen inventaris dan kasir berbasis cloud-serverless yang terintegrasi penuh, dirancang untuk meminimalisir human error dalam pelacakan Serial Number (SN).',
        fullDesc: 'RetinaCCTV Pro adalah solusi perangkat lunak kustom yang dibangun untuk mengatasi masalah manajemen stok barang elektronik yang memiliki identitas unik (Serial Number/SN). Aplikasi ini menggabungkan dua fungsi vital: Manajemen Gudang (Back Office) dan Mesin Kasir (Front Office/POS) dalam satu database terpusat.\n\nSistem ini mengubah Google Spreadsheet menjadi database relasional yang kuat, diakses melalui antarmuka web modern yang responsif. Fokus utama pengembangan adalah pada kecepatan input data melalui barcode scanner, validasi data ganda otomatis untuk mencegah kerugian aset, serta pencatatan transaksi penjualan yang akurat dengan perhitungan PPN otomatis dan pencetakan struk termal.',
        image: '/src/assets/images/projects/card2.png',
        thumbnail: '/src/assets/images/projects/card2.png',
        isCover: true,
        liveUrl: 'https://github.com/SyafiqSiregar/RetinaCCTV-Pro-System.git',
        role: 'Full Stack Developer (Konseptor Sistem, UI/UX Designer)',
        client: 'CV RETINA PERISAI NUSANTARA',
        year: '2026',
        techStack: ['Google Apps Script', 'Google Sheets', 'HTML', 'CSS'],
        features: [
            { icon: '🔀', title: 'Dual-Interface System', desc: 'Pemisahan akses UI antara Admin Gudang (Manajemen Stok) dan Kasir (Penjualan) melalui satu URL dinamis, menjaga keamanan akses fitur.' },
            { icon: '📡', title: 'Smart Barcode Scanning', desc: 'Alur kerja input "Scan-to-Action". Scan Part Number (PN) otomatis mendeteksi nama barang, dan Scan Serial Number (SN) memvalidasi keaslian stok.' },
            { icon: '🧾', title: 'Advanced POS with Tax Logic', desc: 'Mesin kasir dengan fitur keranjang belanja, kalkulasi otomatis PPN 10%, hitung kembalian, dan direct printing ke printer thermal (58mm/80mm).' },
            { icon: '🛡️', title: 'Anti-Duplication Security', desc: 'Algoritma validasi ketat yang menolak input SN yang sama pada barang masuk, atau menjual barang yang SN-nya belum terdaftar di gudang.' },
            { icon: '🔐', title: 'Keamanan & Backup Data', desc: 'Fitur destruktif dilindungi Double Authentication. Auto backup satu klik ke .xlsx dengan pengecualian sheet User untuk privasi.' },
            { icon: '📊', title: 'Dashboard & Visualisasi', desc: 'Visualisasi data stok dan penjualan real-time menggunakan Chart.js untuk membantu pengambilan keputusan bisnis.' },
        ],
        sections: [
            {
                type: 'grid-cards',
                badge: 'ARSITEKTUR',
                title: 'Arsitektur & Teknologi Sistem',
                cards: [
                    { icon: '☁️', color: '#0984e3', title: 'Serverless Google', desc: 'Backend dibangun di atas Google Apps Script sebagai API, mengubah biaya server menjadi Rp 0,-.' },
                    { icon: '📋', color: '#6c5ce7', title: 'Spreadsheet as DB', desc: 'Google Sheets sebagai database relasional real-time dengan tabel terpisah untuk Master Barang, Riwayat, Penjualan, Supplier, dan User.' },
                    { icon: '🖥️', color: '#00cec9', title: 'Modern Web UI', desc: 'Frontend responsif dengan HTML5, Bootstrap 5, DataTables untuk tabel interaktif, dan SweetAlert2 untuk UX yang menyenangkan.' },
                    { icon: '🔗', color: '#fd79a8', title: 'Google Drive API', desc: 'Integrasi penuh dengan ekosistem Google untuk penyimpanan, autentikasi, dan pengelolaan file.' },
                ]
            },
            {
                type: 'grid-cards',
                title: 'Smart Workflow & UX',
                cards: [
                    { icon: '🎯', color: '#e17055', title: 'Auto-Focus & Auto-Select', desc: 'Scan barcode PN, kursor otomatis melompat ke kolom berikutnya tanpa sentuh mouse.' },
                    { icon: '🔒', color: '#0984e3', title: 'Read-Only Safety', desc: 'Qty dikunci di "1" pada mode SN, memaksa scan per unit untuk akurasi 100%.' },
                    { icon: '📦', color: '#6c5ce7', title: 'Supplier Tracking', desc: 'Scan di kasir otomatis menampilkan asal Supplier dari data historis penerimaan, memudahkan klaim garansi.' },
                    { icon: '🖨️', color: '#00cec9', title: 'Split View POS', desc: 'Panel Transaksi (kiri) dengan kalkulasi real-time dan Keranjang Belanja (kanan) dengan thermal printing CSS.' },
                ]
            },
        ],
        results: [
            'Efisiensi Biaya: Mengurangi biaya infrastruktur server menjadi Rp 0,- dengan memanfaatkan ekosistem Google',
            'Akurasi Data: Mengeliminasi 99% kesalahan input data ganda atau penjualan barang "hantu"',
            'Kecepatan Operasional: Mempercepat proses stok opname dan transaksi kasir hingga 3x lipat dibandingkan metode manual',
        ],
    },
    {
        icon: '🎨',
        title: 'Galleri Design Portfolio',
        theme: 'design',
        tags: ['Graphic Design', 'Branding', 'Visual Art'],
        desc: 'Koleksi karya desain visual, poster, dan identitas brand dengan estetika futuristik.',
        fullDesc: 'Sebuah showcase dari eksplorasi visual dan proyek desain grafis yang menggabungkan prinsip desain modern dengan sentuhan artistik. Portofolio ini mencakup berbagai media mulai dari poster acara, materi branding, hingga antarmuka pengguna eksperimental, semuanya dirancang untuk menyampaikan pesan yang kuat melalui visual yang memikat.',
        image: '/src/assets/images/projects/ke 3.png',
        thumbnail: '/src/assets/images/projects/ke 3.png',
        isCover: true,
        liveUrl: '#',
        role: 'Graphic Designer & Visual Artist',
        client: 'Various Clients',
        year: '2023 - Present',
        techStack: ['Photoshop', 'Illustrator', 'Figma', 'Blender'],
        features: [
            { icon: '✨', title: 'Visual Storytelling', desc: 'Menyampaikan narasi kompleks melalui komposisi visual yang intuitif dan emosional.' },
            { icon: '🎭', title: 'Brand Identity', desc: 'Membangun karakter brand yang kuat dan konsisten di berbagai touchpoint visual.' },
        ],
        sections: [
            {
                type: 'grid-cards',
                title: 'Review UI/UX Seabank',
                cards: [
                    { image: '/src/assets/images/Review uiux/1.png', color: '#6c5ce7' },
                    { image: '/src/assets/images/Review uiux/2.png', color: '#0984e3' },
                    { image: '/src/assets/images/Review uiux/3.png', color: '#00cec9' },
                    { image: '/src/assets/images/Review uiux/4.png', color: '#fd79a8' },
                    { image: '/src/assets/images/Review uiux/5.png', color: '#a29bfe' },
                    { image: '/src/assets/images/Review uiux/6.png', color: '#e17055' },
                ]
            },
            {
                type: 'grid-cards',
                title: 'Desain Poster & UMKM',
                cards: [
                    { image: '/src/assets/images/UMKM/15.png', color: '#6c5ce7' },
                    { image: '/src/assets/images/UMKM/16.png', color: '#0984e3' },
                    { image: '/src/assets/images/UMKM/17.png', color: '#00cec9' },
                    { image: '/src/assets/images/UMKM/18.png', color: '#fd79a8' },
                ]
            },
            {
                type: 'masonry-gallery',
                title: 'Poster Collection',
                description: 'Seri desain poster eksperimental dengan komposisi dinamis.',
                images: [
                    '/src/assets/images/Poster/1.png',
                    '/src/assets/images/Poster/2.png',
                    '/src/assets/images/Poster/3.png',
                    '/src/assets/images/Poster/4.png',
                    '/src/assets/images/Poster/5.png',
                    '/src/assets/images/Poster/6.png',
                    '/src/assets/images/Poster/7.png',
                    '/src/assets/images/Poster/8.png',
                    '/src/assets/images/Poster/9.png',
                    '/src/assets/images/Poster/10.png',
                ]
            },
            {
                type: 'design-gallery',
                title: 'Selected Works',
                items: [
                    { image: '/src/assets/images/projects/card2.png', title: 'Futuristic Event Poster', desc: 'Poster acara musik elektronik dengan tipografi kustom dan elemen 3D neon.', delay: 0 },
                    { image: '/src/assets/images/projects/adsa.png', title: 'Tech Startup Branding', desc: 'Identitas visual lengkap untuk startup teknologi, termasuk logo dan social media kit.', delay: 100 },
                    { image: '/src/assets/images/projects/iventory system.png', title: 'Dashboard UI Concept', desc: 'Eksperimen antarmuka pengguna untuk sistem manajemen data yang kompleks.', delay: 200 },
                    // Add more placeholders to show the grid effect
                    { image: '/src/assets/images/profile/profile.jpeg', title: 'Personal Branding', desc: 'Eksplorasi visual personal branding dengan gaya fotografi modern.', delay: 300 },
                ]
            }
        ],
        results: [
            'Meningkatkan engagement visual pada media sosial klien hingga 150%',
            'Menciptakan identitas visual yang unik dan mudah diingat',
            'Menyampaikan pesan marketing dengan lebih efektif melalui desain',
        ],
    },
    {
        icon: '🧪',
        title: 'The Innovation Lab',
        theme: 'lab',
        tags: ['Experimental', 'Creative Coding', 'Interactive'],
        desc: 'Kompilasi proyek eksperimental dengan interaksi "Next-Gen" dan visual cyber-industrial.',
        // fullDesc removed to hide "About" section
        image: '',
        thumbnail: '',
        isCover: true,
        liveUrl: '#',
        hideCover: true,
        hideMeta: true,
        hideHeader: true,
        showKernel: true,
        showLogs: true,
        showHoloCTA: true,
        showDecorations: true,
        showScanner: true,
        showMeteors: true,
        logs: [
            { id: 'LOG_01', status: 'SUCCESS', msg: 'Immersive web experience achieved.', metric: 'Latency: 16ms | FPS: 60' },
            { id: 'LOG_02', status: 'SUCCESS', msg: 'Browser rendering capabilities exhausted.', metric: 'WebGL Context: Active | Shaders: Optimized' },
            { id: 'LOG_03', status: 'DATA', msg: 'User engagement metrics exceeded baseline.', metric: 'Session Duration: +140%' }
        ],
        role: 'Creative Technologist',
        client: 'Personal R&D',
        year: '2024 - Present',
        techStack: ['React', 'Three.js', 'WebGL', 'GLSL'],
        // features removed to hide "Key Features" section
        sections: [
            {
                type: 'innovation-lab',
                title: 'Lab Experiments',
            }
        ],
        results: ['Menciptakan pengalaman web yang immersive', 'Eksplorasi batas kemampuan browser modern'],
    },
];
