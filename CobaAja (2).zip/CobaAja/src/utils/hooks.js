import { useState, useEffect, useRef } from 'react';

export function useScrollReveal() {
    const ref = useRef(null);
    useEffect(() => {
        const el = ref.current;
        if (!el) return;
        const obs = new IntersectionObserver(([e]) => {
            if (e.isIntersecting) { el.classList.add('active'); obs.unobserve(el); }
        }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
        obs.observe(el);
        return () => obs.disconnect();
    }, []);
    return ref;
}

export function useCounter(target, duration = 3000, delay = 0) {
    const [val, setVal] = useState(0);
    const [isVisible, setIsVisible] = useState(false);
    const ref = useRef(null);

    useEffect(() => {
        const el = ref.current;
        if (!el) return;
        const obs = new IntersectionObserver(([e]) => {
            if (e.isIntersecting) {
                setIsVisible(true);
                obs.disconnect();
            }
        }, { threshold: 0.5 });
        obs.observe(el);
        return () => obs.disconnect();
    }, []);

    useEffect(() => {
        if (!isVisible) return;

        const runAnimation = () => {
            setTimeout(() => {
                const start = performance.now();
                const animate = (now) => {
                    const p = Math.min((now - start) / duration, 1);
                    const eased = 1 - Math.pow(1 - p, 4);
                    setVal(Math.floor(target * eased));
                    if (p < 1) requestAnimationFrame(animate);
                };
                requestAnimationFrame(animate);
            }, delay);
        };

        runAnimation();
        const interval = setInterval(runAnimation, 10000);

        return () => clearInterval(interval);
    }, [isVisible, target, duration, delay]);

    return [val, ref];
}

export function useTilt() {
    const ref = useRef(null);
    useEffect(() => {
        const el = ref.current;
        if (!el) return;
        const handleMove = (e) => {
            const rect = el.getBoundingClientRect();
            const x = (e.clientX - rect.left) / rect.width;
            const y = (e.clientY - rect.top) / rect.height;
            const rotateX = (y - 0.5) * -12;
            const rotateY = (x - 0.5) * 12;
            el.style.transform = `perspective(800px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02,1.02,1.02)`;
            const shine = el.querySelector('.card-shine');
            if (shine) { shine.style.setProperty('--shine-x', (x * 100) + '%'); shine.style.setProperty('--shine-y', (y * 100) + '%'); }
        };
        const handleLeave = () => { el.style.transform = 'perspective(800px) rotateX(0) rotateY(0) scale3d(1,1,1)'; };
        el.addEventListener('mousemove', handleMove);
        el.addEventListener('mouseleave', handleLeave);
        return () => { el.removeEventListener('mousemove', handleMove); el.removeEventListener('mouseleave', handleLeave); };
    }, []);
    return ref;
}

export function useMagnetic() {
    const ref = useRef(null);
    useEffect(() => {
        const el = ref.current;
        if (!el) return;
        const handleMove = (e) => {
            const { left, top, width, height } = el.getBoundingClientRect();
            const x = (e.clientX - (left + width / 2)) * 0.5;
            const y = (e.clientY - (top + height / 2)) * 0.5;
            el.style.transform = `translate(${x}px, ${y}px)`;
        };
        const handleLeave = () => {
            el.style.transform = 'translate(0px, 0px)';
        };
        el.addEventListener('mousemove', handleMove);
        el.addEventListener('mouseleave', handleLeave);
        return () => {
            el.removeEventListener('mousemove', handleMove);
            el.removeEventListener('mouseleave', handleLeave);
        };
    }, []);
    return ref;
}
