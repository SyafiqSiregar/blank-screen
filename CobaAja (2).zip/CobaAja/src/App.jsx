import React, { useState } from 'react';
import Home from './pages/Home/Home';
import ProjectDetail from './pages/ProjectDetail/ProjectDetail';
import CursorGlow from './components/ui/CursorGlow';
import './styles/main.css';

// App Component
export default function App() {
    const [view, setView] = useState('home'); // 'home' or 'project'
    const [activeProject, setActiveProject] = useState(null);

    const handleProjectClick = (project) => {
        setActiveProject(project);
        setView('project');
    };

    const handleBack = () => {
        setView('home');
        setActiveProject(null);
    };

    return (
        <>
            <CursorGlow />
            {view === 'home' ? (
                <Home onProjectClick={handleProjectClick} />
            ) : (
                <ProjectDetail project={activeProject} onBack={handleBack} />
            )}
        </>
    );
}
