import { useState, useEffect } from 'react';
import { useScrollReveal } from '../../utils/hooks';

function CodeTypewriter() {
    const codeLines = [
        [
            { text: "const", Class: "keyword" }, { text: " " },
            { text: "project", Class: "var" }, { text: " = " },
            { text: "new", Class: "keyword" }, { text: " " },
            { text: "Project", Class: "class" }, { text: "();" }
        ],
        [
            { text: "project", Class: "var" }, { text: "." },
            { text: "collaborator", Class: "prop" }, { text: " = " },
            { text: "\"Syafiq Siregar\"", Class: "string" }, { text: ";" }
        ],
        [
            { text: "project", Class: "var" }, { text: "." },
            { text: "status", Class: "prop" }, { text: " = " },
            { text: "\"Success\"", Class: "string" }, { text: ";" }
        ],
        [], // Empty line
        [
            { text: "// Ready to launch?", Class: "comment" }
        ],
        [
            { text: "await", Class: "keyword" }, { text: " " },
            { text: "contactMe", Class: "func" }, { text: "();" }
        ]
    ];

    const [displayedContent, setDisplayedContent] = useState([[]]);
    const [cursorVisible, setCursorVisible] = useState(true);

    useEffect(() => {
        let isMounted = true;
        let lineIdx = 0;
        let tokenIdx = 0;
        let charIdx = 0;
        let currentLines = [[]];

        const typeChar = () => {
            if (!isMounted) return;

            // If we've finished all lines, wait 5 seconds and reset
            if (lineIdx >= codeLines.length) {
                setTimeout(() => {
                    if (!isMounted) return;
                    lineIdx = 0;
                    tokenIdx = 0;
                    charIdx = 0;
                    currentLines = [[]];
                    setDisplayedContent([[]]);
                    typeChar();
                }, 5000);
                return;
            }

            const speed = 30 + Math.random() * 40;
            const currentLine = codeLines[lineIdx];

            if (tokenIdx >= currentLine.length) {
                lineIdx++;
                tokenIdx = 0;
                charIdx = 0;

                if (lineIdx < codeLines.length) {
                    currentLines.push([]);
                    setDisplayedContent([...currentLines]);
                    setTimeout(typeChar, 100);
                } else {
                    // Trigger the finish check on next tick
                    typeChar();
                }
                return;
            }

            const currentToken = currentLine[tokenIdx];
            const char = currentToken.text[charIdx];

            if (!currentLines[lineIdx]) currentLines[lineIdx] = [];
            const lineArr = currentLines[lineIdx];

            if (lineArr.length <= tokenIdx) {
                lineArr.push({ text: char, Class: currentToken.Class });
            } else {
                lineArr[tokenIdx].text += char;
            }

            setDisplayedContent([...currentLines]);

            charIdx++;
            if (charIdx >= currentToken.text.length) {
                tokenIdx++;
                charIdx = 0;
            }

            setTimeout(typeChar, speed);
        };

        const timer = setTimeout(typeChar, 500);
        const cursorInterval = setInterval(() => {
            if (isMounted) setCursorVisible(v => !v);
        }, 500);

        return () => {
            isMounted = false;
            clearTimeout(timer);
            clearInterval(cursorInterval);
        };
    }, []);

    return (
        <div className="code-content">
            {displayedContent.map((line, i) => (
                <div key={i} className="code-line">
                    {line.length === 0 && <br />}
                    {line.map((token, j) => (
                        <span key={j} className={token.Class}>{token.text}</span>
                    ))}
                    {i === displayedContent.length - 1 && (
                        <span className="cursor" style={{ opacity: cursorVisible ? 1 : 0 }}>|</span>
                    )}
                </div>
            ))}
        </div>
    );
}

export default function CTASection() {
    const ref = useScrollReveal();
    return (
        <section className="cta-section" id="contact">
            <div className="container">
                <div className="cta-grid reveal" ref={ref}>
                    <div className="cta-left-col">
                        <div className="cta-header">
                            <h2>Let's build something <br /><span className="gradient-text">extraordinary</span> together</h2>
                            <p>I'm currently available for freelance projects and open to new opportunities. Let's turn your ideas into reality.</p>
                        </div>

                        <div className="coding-animation">
                            <div className="window-bar">
                                <span className="dot red"></span>
                                <span className="dot yellow"></span>
                                <span className="dot green"></span>
                            </div>
                            <CodeTypewriter />
                        </div>
                    </div>

                    <div className="cta-form-card tilt-card">
                        <div className="card-shine" />
                        <h3>Execute your vision</h3>
                        <p>Ready to define the future? Tell me about your project context and let's craft a solution.</p>
                        <form className="contact-form" onSubmit={(e) => {
                            e.preventDefault();
                            const name = e.target.name.value;
                            const email = e.target.user_email.value;
                            const message = e.target.message.value;
                            const waText = `Halo Syafiq! 👋\n\n*Nama:* ${name}\n*Email:* ${email}\n*Project Brief:*\n${message}`;
                            const waUrl = `https://wa.me/6287792490128?text=${encodeURIComponent(waText)}`;
                            window.open(waUrl, '_blank');
                        }}>
                            <div className="form-group floating-label">
                                <input type="text" name="name" id="name" placeholder=" " required />
                                <label htmlFor="name">Your Name</label>
                            </div>
                            <div className="form-group floating-label">
                                <input type="email" name="user_email" id="email" placeholder=" " required />
                                <label htmlFor="email">Email Address</label>
                            </div>
                            <div className="form-group floating-label">
                                <textarea name="message" id="message" placeholder=" " rows="4" required></textarea>
                                <label htmlFor="message">Project Brief</label>
                            </div>
                            <button type="submit" className="btn-primary full-width magic-hover">
                                <span className="btn-text">Initiate Collaboration</span>
                                <span className="btn-particles"></span>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    );
}
