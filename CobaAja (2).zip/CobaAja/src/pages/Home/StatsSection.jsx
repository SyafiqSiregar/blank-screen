import { useCounter, useScrollReveal } from '../../utils/hooks';

function StatItem({ target, label, suffix = '+', delay = 0, index }) {
    const [val, ref] = useCounter(target, 2000, delay);
    const revRef = useScrollReveal();
    return (
        <div className="stat-item reveal" ref={e => { ref.current = e; revRef.current = e; }} style={{ transitionDelay: `${delay}ms` }}>
            <div className="stat-step-circle">{index + 1}</div>
            <div className="stat-number">{val}{suffix}</div>
            <div className="stat-label">{label}</div>
            <div className="stat-card-glow" />
        </div>
    );
}

export default function StatsSection() {
    return (
        <section className="stats">
            <div className="container">
                <div className="stats-relative-wrapper">
                    <div className="stats-line-container">
                        <div className="stats-line-bg"></div>
                        <div className="stats-line-progress"></div>
                        <div className="stats-moving-light light-1"></div>
                        <div className="stats-moving-light light-2"></div>
                        <div className="stats-moving-light light-3"></div>
                        <div className="stats-moving-light light-4"></div>
                    </div>
                    <div className="stats-grid">
                        <StatItem target={20} label="Projects Completed" index={0} delay={0} />
                        <StatItem target={95} label="Client Satisfaction" suffix="%" index={1} delay={200} />
                        <StatItem target={2} label="Years Experience" suffix="+" index={2} delay={400} />
                        <StatItem target={10} label="Happy Clients" index={3} delay={600} />
                    </div>
                </div>
            </div>
        </section>
    );
}
