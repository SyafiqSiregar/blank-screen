import { useState, useEffect, useRef } from 'react';
import { useMagnetic } from '../../utils/hooks';
import TypingText from '../../components/ui/TypingText';

export default function HeroSection() {
    const skills = ['UI/UX Designer', 'Web Developer', 'Software Engineer', 'Graphic Designer'];
    const skillIcons = ['🎨', '💻', '⚙️', '✏️'];
    const [flipped, setFlipped] = useState(false);
    const btnRef1 = useMagnetic();
    const btnRef2 = useMagnetic();

    useEffect(() => {
        const interval = setInterval(() => {
            setFlipped(prev => !prev);
        }, 5000);
        return () => clearInterval(interval);
    }, []);

    // Rocket animation component inside to keep logic contained or can be extracted further
    const RocketInfinity = () => {
        const rocketRef = useRef(null);
        const trailRef = useRef(null);
        useEffect(() => {
            const el = rocketRef.current;
            if (!el) return;
            let t = 0;
            let frame;
            const speed = 0.008; // slow smooth orbit
            const animate = () => {
                t += speed;
                // Figure-8 lemniscate parametric: x = sin(t), y = sin(t)*cos(t)
                const radiusX = 520;
                const radiusY = 250;
                const x = Math.sin(t) * radiusX;
                const y = Math.sin(t) * Math.cos(t) * radiusY;
                // Tangent direction: dx/dt = cos(t), dy/dt = cos(2t)
                const dx = Math.cos(t) * radiusX;
                const dy = Math.cos(2 * t) * radiusY;
                const angle = Math.atan2(dy, dx) * (180 / Math.PI);
                // Rocket SVG points up (nose at top), so subtract 90° to align nose with path
                el.style.transform = `translate(${x}px, ${y}px) rotate(${angle + 90}deg)`;
                frame = requestAnimationFrame(animate);
            };
            frame = requestAnimationFrame(animate);
            return () => cancelAnimationFrame(frame);
        }, []);
        return (
            <div className="rocket-infinity-container">
                {/* Faint infinity trail */}
                <svg className="infinity-trail" viewBox="-550 -270 1100 540" fill="none" xmlns="http://www.w3.org/2000/svg" ref={trailRef}>
                    <path d={(() => {
                        let d = '';
                        for (let i = 0; i <= 200; i++) {
                            const a = (i / 200) * Math.PI * 2;
                            const px = Math.sin(a) * 520;
                            const py = Math.sin(a) * Math.cos(a) * 250;
                            d += (i === 0 ? 'M' : 'L') + px.toFixed(1) + ' ' + py.toFixed(1);
                        }
                        return d + 'Z';
                    })()} stroke="rgba(162,155,254,0.06)" strokeWidth="1.5" strokeDasharray="6 8" />
                </svg>
                {/* Rocket */}
                <div className="rocket-infinity" ref={rocketRef}>
                    <svg viewBox="0 0 120 300" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <defs>
                            <linearGradient id="rocket-body-l" x1="50%" y1="0%" x2="50%" y2="100%">
                                <stop offset="0%" stopColor="#a29bfe" />
                                <stop offset="50%" stopColor="#6c5ce7" />
                                <stop offset="100%" stopColor="#4834d4" />
                            </linearGradient>
                            <linearGradient id="rocket-window-l" x1="50%" y1="0%" x2="50%" y2="100%">
                                <stop offset="0%" stopColor="#00cec9" />
                                <stop offset="100%" stopColor="#6c5ce7" />
                            </linearGradient>
                            <linearGradient id="rocket-flame-l" x1="50%" y1="0%" x2="50%" y2="100%">
                                <stop offset="0%" stopColor="#fd79a8" />
                                <stop offset="40%" stopColor="#fdcb6e" />
                                <stop offset="100%" stopColor="#fd79a8" stopOpacity="0" />
                            </linearGradient>
                            <filter id="rocket-glow-l">
                                <feGaussianBlur stdDeviation="3" result="blur" />
                                <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
                            </filter>
                        </defs>
                        <path d="M60 30 C60 30 45 60 45 110 L45 170 C45 180 75 180 75 170 L75 110 C75 60 60 30 60 30Z" fill="url(#rocket-body-l)" opacity="0.8" stroke="rgba(162,155,254,0.7)" strokeWidth="1.2" />
                        <path d="M60 30 C60 30 52 50 50 80 L60 75 Z" fill="rgba(255,255,255,0.3)" />
                        <circle cx="60" cy="100" r="10" fill="rgba(0,206,201,0.3)" stroke="url(#rocket-window-l)" strokeWidth="1.5" opacity="0.9" />
                        <circle cx="60" cy="100" r="6" fill="url(#rocket-window-l)" opacity="0.5">
                            <animate attributeName="opacity" values="0.5;0.8;0.5" dur="3s" repeatCount="indefinite" />
                        </circle>
                        <path d="M45 150 L25 180 L45 170Z" fill="url(#rocket-body-l)" opacity="0.5" stroke="rgba(162,155,254,0.5)" strokeWidth="0.8" />
                        <path d="M75 150 L95 180 L75 170Z" fill="url(#rocket-body-l)" opacity="0.5" stroke="rgba(162,155,254,0.5)" strokeWidth="0.8" />
                        <ellipse cx="60" cy="190" rx="12" ry="25" fill="url(#rocket-flame-l)" opacity="0.6" filter="url(#rocket-glow-l)">
                            <animate attributeName="ry" values="25;35;25" dur="0.6s" repeatCount="indefinite" />
                            <animate attributeName="opacity" values="0.6;0.3;0.6" dur="0.4s" repeatCount="indefinite" />
                        </ellipse>
                        <ellipse cx="60" cy="190" rx="6" ry="15" fill="#fdcb6e" opacity="0.4">
                            <animate attributeName="ry" values="15;22;15" dur="0.5s" repeatCount="indefinite" />
                        </ellipse>
                        <circle cx="55" cy="220" r="2" fill="#fd79a8" opacity="0.4">
                            <animate attributeName="cy" values="220;260;220" dur="1.5s" repeatCount="indefinite" />
                            <animate attributeName="opacity" values="0.4;0;0.4" dur="1.5s" repeatCount="indefinite" />
                        </circle>
                    </svg>
                </div>
            </div>
        );
    }

    return (
        <section className="hero" id="hero" style={{ position: 'relative' }}>
            <RocketInfinity />
            <div className="container">
                <div className="hero-content">
                    <div className="profile-wrapper" onClick={() => setFlipped(!flipped)}>
                        <div className={`profile-flipper${flipped ? ' flipped' : ''}`}>
                            <div className="profile-photo front" style={{ backgroundImage: 'url(/src/assets/images/profile/profile.jpeg)', backgroundSize: 'cover' }} />
                            <div className="profile-photo back" style={{ backgroundImage: 'url(/src/assets/images/profile/profile2.jpg)', backgroundSize: 'cover' }} />
                        </div>
                        <div className="profile-ring" />
                        <div className="profile-ring-2" />
                        <div className="profile-status" />
                    </div>

                    <div className="masked-reveal">
                        <h1>Hello, I'm <span className="gradient-text">Syafiq Siregar</span></h1>
                    </div>

                    <div className="subtitle">
                        <TypingText texts={skills} speed={70} pause={2500} />
                    </div>

                    <p className="hero-desc">Crafting beautiful digital experiences through design thinking, clean code, and creative innovation.</p>

                    <div className="skill-tags">
                        {skills.map((s, i) => (
                            <div className="skill-tag" key={i}>
                                <span><span className="tag-icon">{skillIcons[i]}</span>{s}</span>
                            </div>
                        ))}
                    </div>

                    <div className="hero-buttons">
                        <a href="#work" className="btn-primary" ref={btnRef1} onClick={e => { e.preventDefault(); document.getElementById('work')?.scrollIntoView({ behavior: 'smooth' }); }}>
                            View My Work <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                        </a>
                        <a href="#contact" className="btn-secondary" ref={btnRef2} onClick={e => { e.preventDefault(); document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' }); }}>
                            Let's Talk <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M2 4l6 4 6-4M2 4v8a1 1 0 001 1h10a1 1 0 001-1V4M2 4a1 1 0 011-1h10a1 1 0 011 1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>
                        </a>
                    </div>
                </div>
            </div>
        </section>
    );
}
