import { useScrollReveal } from '../../utils/hooks';
import { FeatureCard } from '../../components/ui/FeatureCard';

export default function FeaturesSection() {
    const ref = useScrollReveal();
    const features = [
        { icon: '🎨', title: 'UI/UX Design', desc: 'Creating intuitive, pixel-perfect interfaces with user-centered design principles and modern aesthetics.', floatIcon: '◆', animType: 'uiux', accentColor: '#a29bfe', delay: 0 },
        { icon: '💻', title: 'Web Development', desc: 'Building responsive, performant websites and web applications using React, Next.js, and modern frameworks.', floatIcon: '⟡', animType: 'webdev', accentColor: '#6c5ce7', delay: 80 },
        { icon: '⚙️', title: 'Software Engineering', desc: 'Architecting scalable software solutions with clean code, design patterns, and best practices.', floatIcon: '◇', animType: 'softeng', accentColor: '#00cec9', delay: 160 },
        { icon: '✏️', title: 'Graphic Design', desc: 'Crafting stunning visual identities, illustrations, and marketing materials that captivate audiences.', floatIcon: '△', animType: 'graphic', accentColor: '#fd79a8', delay: 240 },
        { icon: '📱', title: 'Mobile First', desc: 'Designing responsive experiences that look and feel amazing on every screen size and device.', floatIcon: '○', animType: 'mobile', accentColor: '#00cec9', delay: 320 },
        { icon: '🚀', title: 'Performance', desc: 'Optimizing every pixel and byte for blazing-fast load times and smooth user experiences.', floatIcon: '☆', animType: 'performance', accentColor: '#fd79a8', delay: 400 },
    ];

    const RocketLeft = () => (
        <svg className="rocket-deco rocket-left" viewBox="0 0 120 300" fill="none" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <linearGradient id="rocket-body-l" x1="50%" y1="0%" x2="50%" y2="100%">
                    <stop offset="0%" stopColor="#a29bfe" />
                    <stop offset="50%" stopColor="#6c5ce7" />
                    <stop offset="100%" stopColor="#4834d4" />
                </linearGradient>
                <linearGradient id="rocket-window-l" x1="50%" y1="0%" x2="50%" y2="100%">
                    <stop offset="0%" stopColor="#00cec9" />
                    <stop offset="100%" stopColor="#6c5ce7" />
                </linearGradient>
                <linearGradient id="rocket-flame-l" x1="50%" y1="0%" x2="50%" y2="100%">
                    <stop offset="0%" stopColor="#fd79a8" />
                    <stop offset="40%" stopColor="#fdcb6e" />
                    <stop offset="100%" stopColor="#fd79a8" stopOpacity="0" />
                </linearGradient>
                <filter id="rocket-glow-l">
                    <feGaussianBlur stdDeviation="3" result="blur" />
                    <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
                </filter>
            </defs>
            {/* Rocket body */}
            <path d="M60 30 C60 30 45 60 45 110 L45 170 C45 180 75 180 75 170 L75 110 C75 60 60 30 60 30Z" fill="url(#rocket-body-l)" opacity="0.55" stroke="rgba(162,155,254,0.6)" strokeWidth="1.2" />
            {/* Nose cone highlight */}
            <path d="M60 30 C60 30 52 50 50 80 L60 75 Z" fill="rgba(255,255,255,0.2)" />
            {/* Window */}
            <circle cx="60" cy="100" r="10" fill="rgba(0,206,201,0.3)" stroke="url(#rocket-window-l)" strokeWidth="1.5" opacity="0.8" />
            <circle cx="60" cy="100" r="6" fill="url(#rocket-window-l)" opacity="0.4">
                <animate attributeName="opacity" values="0.4;0.7;0.4" dur="3s" repeatCount="indefinite" />
            </circle>
            {/* Fins */}
            <path d="M45 150 L25 180 L45 170Z" fill="url(#rocket-body-l)" opacity="0.4" stroke="rgba(162,155,254,0.5)" strokeWidth="0.8" />
            <path d="M75 150 L95 180 L75 170Z" fill="url(#rocket-body-l)" opacity="0.4" stroke="rgba(162,155,254,0.5)" strokeWidth="0.8" />
            {/* Exhaust flames */}
            <ellipse cx="60" cy="190" rx="12" ry="25" fill="url(#rocket-flame-l)" opacity="0.5" filter="url(#rocket-glow-l)">
                <animate attributeName="ry" values="25;35;25" dur="0.6s" repeatCount="indefinite" />
                <animate attributeName="opacity" values="0.5;0.3;0.5" dur="0.4s" repeatCount="indefinite" />
            </ellipse>
            <ellipse cx="60" cy="190" rx="6" ry="15" fill="#fdcb6e" opacity="0.35">
                <animate attributeName="ry" values="15;22;15" dur="0.5s" repeatCount="indefinite" />
            </ellipse>
            {/* Exhaust particles */}
            <circle cx="55" cy="220" r="2" fill="#fd79a8" opacity="0.4">
                <animate attributeName="cy" values="220;260;220" dur="1.5s" repeatCount="indefinite" />
                <animate attributeName="opacity" values="0.4;0;0.4" dur="1.5s" repeatCount="indefinite" />
            </circle>
            <circle cx="65" cy="230" r="1.5" fill="#a29bfe" opacity="0.3">
                <animate attributeName="cy" values="230;270;230" dur="1.8s" repeatCount="indefinite" />
                <animate attributeName="opacity" values="0.3;0;0.3" dur="1.8s" repeatCount="indefinite" />
            </circle>
            <circle cx="58" cy="240" r="1.5" fill="#fdcb6e" opacity="0.3">
                <animate attributeName="cy" values="240;280;240" dur="2s" repeatCount="indefinite" />
                <animate attributeName="opacity" values="0.3;0;0.3" dur="2s" repeatCount="indefinite" />
            </circle>
            {/* Star sparkles */}
            <circle cx="30" cy="60" r="1.5" fill="#a29bfe" opacity="0.5">
                <animate attributeName="opacity" values="0.5;0.1;0.5" dur="2.5s" repeatCount="indefinite" />
            </circle>
            <circle cx="90" cy="130" r="1.2" fill="#00cec9" opacity="0.5">
                <animate attributeName="opacity" values="0.1;0.5;0.1" dur="3s" repeatCount="indefinite" />
            </circle>
        </svg>
    );

    const RocketRight = () => (
        <svg className="rocket-deco rocket-right" viewBox="0 0 120 300" fill="none" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <linearGradient id="rocket-body-r" x1="50%" y1="0%" x2="50%" y2="100%">
                    <stop offset="0%" stopColor="#00cec9" />
                    <stop offset="50%" stopColor="#6c5ce7" />
                    <stop offset="100%" stopColor="#4834d4" />
                </linearGradient>
                <linearGradient id="rocket-window-r" x1="50%" y1="0%" x2="50%" y2="100%">
                    <stop offset="0%" stopColor="#fd79a8" />
                    <stop offset="100%" stopColor="#a29bfe" />
                </linearGradient>
                <linearGradient id="rocket-flame-r" x1="50%" y1="0%" x2="50%" y2="100%">
                    <stop offset="0%" stopColor="#a29bfe" />
                    <stop offset="40%" stopColor="#00cec9" />
                    <stop offset="100%" stopColor="#6c5ce7" stopOpacity="0" />
                </linearGradient>
                <filter id="rocket-glow-r">
                    <feGaussianBlur stdDeviation="3" result="blur" />
                    <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
                </filter>
            </defs>
            {/* Rocket body */}
            <path d="M60 30 C60 30 45 60 45 110 L45 170 C45 180 75 180 75 170 L75 110 C75 60 60 30 60 30Z" fill="url(#rocket-body-r)" opacity="0.55" stroke="rgba(0,206,201,0.6)" strokeWidth="1.2" />
            {/* Nose cone highlight */}
            <path d="M60 30 C60 30 68 50 70 80 L60 75 Z" fill="rgba(255,255,255,0.2)" />
            {/* Window */}
            <circle cx="60" cy="100" r="10" fill="rgba(253,121,168,0.25)" stroke="url(#rocket-window-r)" strokeWidth="1.5" opacity="0.8" />
            <circle cx="60" cy="100" r="6" fill="url(#rocket-window-r)" opacity="0.4">
                <animate attributeName="opacity" values="0.4;0.7;0.4" dur="3.5s" repeatCount="indefinite" />
            </circle>
            {/* Fins */}
            <path d="M45 150 L25 180 L45 170Z" fill="url(#rocket-body-r)" opacity="0.4" stroke="rgba(0,206,201,0.5)" strokeWidth="0.8" />
            <path d="M75 150 L95 180 L75 170Z" fill="url(#rocket-body-r)" opacity="0.4" stroke="rgba(0,206,201,0.5)" strokeWidth="0.8" />
            {/* Exhaust flames */}
            <ellipse cx="60" cy="190" rx="12" ry="25" fill="url(#rocket-flame-r)" opacity="0.5" filter="url(#rocket-glow-r)">
                <animate attributeName="ry" values="25;32;25" dur="0.7s" repeatCount="indefinite" />
                <animate attributeName="opacity" values="0.5;0.3;0.5" dur="0.5s" repeatCount="indefinite" />
            </ellipse>
            <ellipse cx="60" cy="190" rx="6" ry="15" fill="#00cec9" opacity="0.35">
                <animate attributeName="ry" values="15;20;15" dur="0.6s" repeatCount="indefinite" />
            </ellipse>
            {/* Exhaust particles */}
            <circle cx="63" cy="225" r="2" fill="#a29bfe" opacity="0.35">
                <animate attributeName="cy" values="225;265;225" dur="1.6s" repeatCount="indefinite" />
                <animate attributeName="opacity" values="0.35;0;0.35" dur="1.6s" repeatCount="indefinite" />
            </circle>
            <circle cx="55" cy="235" r="1.5" fill="#00cec9" opacity="0.3">
                <animate attributeName="cy" values="235;275;235" dur="2s" repeatCount="indefinite" />
                <animate attributeName="opacity" values="0.3;0;0.3" dur="2s" repeatCount="indefinite" />
            </circle>
            {/* Star sparkles */}
            <circle cx="90" cy="55" r="1.5" fill="#00cec9" opacity="0.5">
                <animate attributeName="opacity" values="0.1;0.5;0.1" dur="2s" repeatCount="indefinite" />
            </circle>
            <circle cx="30" cy="140" r="1.2" fill="#fd79a8" opacity="0.4">
                <animate attributeName="opacity" values="0.4;0.1;0.4" dur="3s" repeatCount="indefinite" />
            </circle>
        </svg>
    );

    return (
        <section className="features" id="features">
            <RocketRight />
            <div className="container">
                <div className="section-header reveal active" ref={ref}>
                    <span className="section-label">My Skills</span>
                    <h2>What I bring to the table</h2>
                    <p>A versatile skill set spanning design, development, and engineering excellence.</p>
                </div>
                <div className="features-grid stagger-children">
                    {features.map((f, i) => <FeatureCard key={i} {...f} />)}
                </div>
            </div>
        </section>
    );
}
