import React, { useState, useEffect } from 'react';
import Navbar from '../../components/layout/Navbar';
import Footer from '../../components/layout/Footer';
import ScrollToTop from '../../components/layout/ScrollToTop';
import HeroSection from './HeroSection';
import FeaturesSection from './FeaturesSection';
import StatsSection from './StatsSection';
import WorkSection from './WorkSection';
import TestimonialsSection from './TestimonialsSection';
import CTASection from './CTASection';

export default function Home({ onProjectClick }) {
    const [scrolled, setScrolled] = useState(false);
    const [showTop, setShowTop] = useState(false);

    useEffect(() => {
        const handler = () => {
            setScrolled(window.scrollY > 50);
            setShowTop(window.scrollY > 400);
        };
        window.addEventListener('scroll', handler);
        return () => window.removeEventListener('scroll', handler);
    }, []);

    return (
        <>
            <Navbar scrolled={scrolled} />
            <div style={{ paddingTop: '100px', textAlign: 'center' }}>
                <h1>Debug Mode: Home Loaded</h1>
                <p>If you see this, the core Home component is working.</p>
            </div>
            {/* 
            <HeroSection />
            <FeaturesSection />
            <StatsSection />
            <WorkSection onProjectClick={onProjectClick} />
            <TestimonialsSection />
            <CTASection />
            <Footer />
            <ScrollToTop visible={showTop} />
             */}
        </>
    );
}
