import { useScrollReveal } from '../../utils/hooks';

export default function TestimonialsSection() {
    const ref = useScrollReveal();
    const testimonials = [
        { initial: 'A', name: 'Ridwan Luthfi Siregar', role: 'CEO, RetinaCCTV', quote: '"Syafiq transformed our vision into a product that exceeded every expectation. His attention to detail is remarkable."' },
        { initial: 'S', name: 'Sarah Chen', role: 'CTO, DataFlow', quote: '"The design quality and technical expertise Syafiq brings is world-class. A true partner in innovation."' },
        { initial: 'M', name: 'Marco Rossi', role: 'Founder, Designlab', quote: '"Working with Syafiq felt effortless. He brought ideas we never imagined and delivered flawlessly."' },
    ];
    return (
        <section className="testimonials" id="testimonials">
            <div className="container">
                <div className="section-header reveal active" ref={ref}>
                    <span className="section-label">Testimonials</span>
                    <h2>What clients say</h2>
                    <p>Feedback from people I've had the privilege of working with.</p>
                </div>
                <div className="testimonials-grid stagger-children">
                    {testimonials.map((t, i) => {
                        const r = useScrollReveal();
                        return (
                            <div key={i} className="testimonial-card reveal" ref={r}>
                                <div className="testimonial-stars">★★★★★</div>
                                <blockquote>{t.quote}</blockquote>
                                <div className="testimonial-author">
                                    <div className="testimonial-avatar">{t.initial}</div>
                                    <div className="testimonial-author-info"><h5>{t.name}</h5><span>{t.role}</span></div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        </section>
    );
}
