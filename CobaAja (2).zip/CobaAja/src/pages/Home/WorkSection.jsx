import { useScrollReveal, useTilt } from '../../utils/hooks';
import { projects } from '../../utils/projectData';

export default function WorkSection({ onProjectClick }) {
    const ref = useScrollReveal();

    return (
        <section className="work" id="work">
            <div className="container">
                <div className="section-header reveal active" ref={ref}>
                    <span className="section-label">Portfolio</span>
                    <h2>Selected projects</h2>
                    <p>A curated selection of my finest work across industries and platforms.</p>
                </div>
                <div className="work-grid stagger-children">
                    {projects.map((p, i) => {
                        const r = useScrollReveal();
                        const t = useTilt();
                        return (
                            <div key={i} className={`work-card reveal tilt-card theme-${p.theme || 'default'}`} ref={e => { r.current = e; t.current = e; }} onClick={() => onProjectClick(p)}>
                                <div className="card-shine" />
                                <div className={`work-card-image${p.isCover ? ' cover-mode' : ''}${p.useContain ? ' contain-mode' : ''}`}>
                                    {p.thumbnail ? (
                                        <img src={p.thumbnail} alt={p.title} />
                                    ) : (
                                        <div className="placeholder">{p.icon}</div>
                                    )}
                                </div>
                                <div className="work-card-info">
                                    <div className="work-card-tags">{p.tags.map((t, j) => <span key={j}>{t}</span>)}</div>
                                    <h3>{p.title}</h3><p>{p.desc}</p>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        </section>
    );
}
