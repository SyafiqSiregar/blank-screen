export default function CyberMeteorRain() {
    // Generate static array for meteors to avoid re-renders causing jumpiness
    const meteors = Array.from({ length: 12 }).map((_, i) => ({
        id: i,
        side: i % 2 === 0 ? 'left' : 'right',
        delay: Math.random() * 5,
        duration: 2 + Math.random() * 3,
        left: i % 2 === 0 ? Math.random() * 100 : undefined,
        right: i % 2 !== 0 ? Math.random() * 100 : undefined,
    }));

    return (
        <div className="lab-meteor-rain-layer">
            <div className="meteor-container left">
                {meteors.filter(m => m.side === 'left').map(m => (
                    <div key={m.id} className="meteor" style={{
                        left: `${m.left}%`,
                        animationDelay: `${m.delay}s`,
                        animationDuration: `${m.duration}s`
                    }}></div>
                ))}
            </div>
            <div className="meteor-container right">
                {meteors.filter(m => m.side === 'right').map(m => (
                    <div key={m.id} className="meteor" style={{
                        right: `${m.right}%`,
                        animationDelay: `${m.delay}s`,
                        animationDuration: `${m.duration}s`
                    }}></div>
                ))}
            </div>
        </div>
    );
}
