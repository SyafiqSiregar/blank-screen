import { useState, useEffect } from 'react';
import { useScrollReveal } from '../../../utils/hooks';

export default function SystemKernelSection() {
    const ref = useScrollReveal();
    const [stats, setStats] = useState({ cpu: 12, mem: 45, net: 20 });

    useEffect(() => {
        const interval = setInterval(() => {
            setStats({
                cpu: Math.floor(Math.random() * 30) + 10,
                mem: Math.floor(Math.random() * 20) + 40,
                net: Math.floor(Math.random() * 50) + 10
            });
        }, 2000);
        return () => clearInterval(interval);
    }, []);

    const modules = [
        { name: 'REACT.JS', type: 'CORE_LOGIC', ver: 'v18.2.0', status: 'ACTIVE' },
        { name: 'THREE.JS', type: 'RENDER_ENGINE', ver: 'r160', status: 'RUNNING' },
        { name: 'WEBGL', type: 'GPU_ACCEL', ver: '2.0', status: 'READY' },
        { name: 'GLSL', type: 'SHADER_LANG', ver: 'ES 3.0', status: 'COMPILED' }
    ];

    return (
        <div className="system-kernel-section reveal" ref={ref}>
            <div className="sys-header">
                <div className="sys-title">
                    <span className="sys-icon">⚡</span> SYSTEM_KERNEL
                </div>
                <div className="sys-line"></div>
                <div className="sys-status">ONLINE</div>
            </div>

            <div className="sys-dashboard">
                <div className="sys-stats-row">
                    <div className="sys-stat-item">
                        <span className="label">CPU_LOAD</span>
                        <div className="bar-container">
                            <div className="bar-fill" style={{ width: `${stats.cpu}%` }}></div>
                        </div>
                        <span className="value">{stats.cpu}%</span>
                    </div>
                    <div className="sys-stat-item">
                        <span className="label">MEMORY</span>
                        <div className="bar-container">
                            <div className="bar-fill" style={{ width: `${stats.mem}%` }}></div>
                        </div>
                        <span className="value">{stats.mem}GB</span>
                    </div>
                    <div className="sys-stat-item">
                        <span className="label">NET_IO</span>
                        <div className="bar-container">
                            <div className="bar-fill" style={{ width: `${stats.net}%` }}></div>
                        </div>
                        <span className="value">{stats.net}MB/s</span>
                    </div>
                </div>

                <div className="sys-modules-grid">
                    {modules.map((m, i) => (
                        <div key={i} className="sys-module-card">
                            <div className="sys-module-header">
                                <span className="mod-name">{m.name}</span>
                                <span className="mod-ver">{m.ver}</span>
                            </div>
                            <div className="sys-module-body">
                                <div className="mod-row">
                                    <span>TYPE:</span> <span>{m.type}</span>
                                </div>
                                <div className="mod-row">
                                    <span>STATUS:</span> <span className="status-ok">{m.status}</span>
                                </div>
                            </div>
                            <div className="sys-corner-tl"></div>
                            <div className="sys-corner-br"></div>
                        </div>
                    ))}
                </div>

                <div className="sys-terminal">
                    <span className="term-prompt">&gt;</span> core_systems_check initiating... <span className="term-cursor">_</span>
                </div>
            </div>
        </div>
    );
}
