import { useScrollReveal } from '../../../utils/hooks';

export default function ExperimentLogsSection({ logs }) {
    const ref = useScrollReveal();

    return (
        <div className="experiment-logs-section reveal" ref={ref}>
            <div className="logs-container">
                <div className="logs-header">
                    <span className="logs-title">&gt;_ ACCESSING_PROJECT_OUTCOMES...</span>
                </div>
                <div className="logs-body">
                    {logs.map((log, i) => (
                        <div key={i} className="log-entry" style={{ animationDelay: `${i * 200}ms` }}>
                            <span className="log-timestamp">[{log.id}]</span>
                            <span className={`log-status status-${log.status.toLowerCase()}`}>[{log.status}]</span>
                            <span className="log-message">:: {log.msg}</span>
                            {log.metric && <div className="log-metric">&gt; {log.metric}</div>}
                        </div>
                    ))}
                    <div className="log-entry log-end">
                        <span className="log-message">// END_OF_LOG</span>
                        <span className="log-cursor">_</span>
                    </div>
                </div>
            </div>
        </div>
    );
}
