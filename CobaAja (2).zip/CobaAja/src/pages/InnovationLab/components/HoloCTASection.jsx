import { useScrollReveal } from '../../../utils/hooks';

export default function HoloCTASection({ onBack }) {
    const ref = useScrollReveal();

    return (
        <div className="holo-cta-section reveal" ref={ref}>
            <div className="holo-container">
                <div className="holo-grid-bg"></div>
                <div className="holo-content">
                    <div className="holo-icon">🤝</div>
                    <h3>INIT_COLLABORATION</h3>
                    <div className="holo-line"></div>
                    <p>Interested in joint research or experimental development?</p>

                    <div className="holo-actions">
                        <a href="mailto:contact@example.com" className="holo-btn primary">
                            <span className="btn-glitch" data-text="[ CONTACT_ME ]">[ CONTACT_ME ]</span>
                            <span className="btn-arrow">&gt;&gt;&gt;</span>
                        </a>
                        <button onClick={onBack} className="holo-btn secondary">
                            <span className="btn-text">[ ACCESS_OTHER_LOGS ]</span>
                        </button>
                    </div>
                </div>
                <div className="holo-corner tl"></div>
                <div className="holo-corner tr"></div>
                <div className="holo-corner bl"></div>
                <div className="holo-corner br"></div>
            </div>
        </div>
    );
}
