export default function LabDecorations() {
    return (
        <div className="lab-decorations-layer">
            <div className="lab-grid-bg"></div>
            <div className="lab-hud-layer">
                <div className="hud-corner tl">
                    <span>[+] SYSTEM_READY</span>
                    <span>V.2.0</span>
                </div>
                <div className="hud-corner tr">
                    <span>SECURE_CONNECTION</span>
                    <span className="hud-dot"></span>
                </div>
                <div className="hud-corner bl">
                    <span className="hud-rec">[ ● REC ]</span>
                </div>
                <div className="hud-corner br">
                    <span>COORD: X:45 Y:12</span>
                </div>

                <div className="hud-side-ruler left"></div>
                <div className="hud-side-ruler right"></div>
            </div>
            <div className="lab-floating-markers">
                <div className="marker m1">+</div>
                <div className="marker m2">+</div>
                <div className="marker m3"></div>
                <div className="marker m4"></div>
            </div>
        </div>
    );
}
