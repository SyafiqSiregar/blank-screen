export default function ScanlineOverlay() {
    return <div className="lab-scanline-overlay"></div>;
}
