import { useState } from 'react';

export const LabVisualWrapper = ({ children, className }) => (
    <div className={`lab-visual-wrapper ${className || ''}`}>
        <div className="lab-visual-inner">
            {children}
        </div>
        <div className="lab-corner tl" />
        <div className="lab-corner tr" />
        <div className="lab-corner bl" />
        <div className="lab-corner br" />
    </div>
);

export const TextDecodingCard = ({ title, subtitle, icon, delay }) => {
    const [displayText, setDisplayText] = useState(title);
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%&";

    const handleHover = () => {
        let iterations = 0;
        const interval = setInterval(() => {
            setDisplayText(title.split("").map((letter, index) => {
                if (index < iterations) return title[index];
                return chars[Math.floor(Math.random() * chars.length)];
            }).join(""));
            if (iterations >= title.length) clearInterval(interval);
            iterations += 1 / 3;
        }, 30);
    };

    return (
        <div className="pd-feature-card theme-lab-card" onMouseEnter={handleHover} style={{ animationDelay: `${delay}ms` }}>
            <div className="lab-card-header">
                <span className="lab-icon">{icon}</span>
                <div className="lab-status-dot" />
            </div>
            <h3 className="txt-decode">{displayText}</h3>
            <p>{subtitle}</p>
            <div className="lab-scanline" />
        </div>
    );
};

export const RealityDistortionCard = ({ title, subtitle, icon, delay }) => {
    // Simplified specific effect for this card without heavy SVG filter for performance first
    // Using CSS transform perspective
    const [style, setStyle] = useState({});

    const handleMove = (e) => {
        const rect = e.currentTarget.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const xPct = (x / rect.width - 0.5) * 20; // -10 to 10 deg
        const yPct = (y / rect.height - 0.5) * -20;

        setStyle({
            transform: `perspective(1000px) rotateX(${yPct}deg) rotateY(${xPct}deg) scale(1.05)`,
            boxShadow: `${-xPct}px ${yPct}px 30px rgba(57, 255, 20, 0.2)`
        });
    };

    const handleLeave = () => {
        setStyle({ transform: 'perspective(1000px) rotateX(0) rotateY(0) scale(1)', boxShadow: 'none' });
    };

    return (
        <div
            className="pd-feature-card theme-lab-card distortion-card"
            onMouseMove={handleMove}
            onMouseLeave={handleLeave}
            style={{ ...style, animationDelay: `${delay}ms`, transition: 'transform 0.1s' }}
        >
            <div className="lab-card-header">
                <span className="lab-icon">{icon}</span>
                <span className="lab-badge">PHYSICS_ENGINE</span>
            </div>
            <h3>{title}</h3>
            <p>{subtitle}</p>
            <div className="liquid-distort" />
        </div>
    );
};

export const GlitchSnapCard = ({ title, subtitle, icon, delay, image }) => {
    return (
        <div className="pd-feature-card theme-lab-card glitch-snap-card" style={{ animationDelay: `${delay}ms` }}>
            <div className="glitch-layer" style={{ backgroundImage: `url(${image})`, backgroundColor: '#1a1a1a' }}></div>
            <div className="glitch-layer" style={{ backgroundImage: `url(${image})`, backgroundColor: '#1a1a1a' }}></div>
            <div className="glitch-layer" style={{ backgroundImage: `url(${image})`, backgroundColor: '#1a1a1a' }}></div>

            <div className="lab-content-overlay">
                <div className="lab-card-header">
                    <span className="lab-icon">{icon}</span>
                    <span className="lab-badge">RECONSTRUCT</span>
                </div>
                <h3>{title}</h3>
                <p>{subtitle}</p>
            </div>
        </div>
    );
};
