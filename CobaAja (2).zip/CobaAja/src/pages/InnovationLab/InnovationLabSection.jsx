import { useState, useEffect } from 'react';
import { useScrollReveal } from '../../utils/hooks';
import LoopingTypingText from '../../components/ui/LoopingTypingText';
import MagneticButton from '../../components/common/MagneticButton';
import { LabVisualWrapper, TextDecodingCard, RealityDistortionCard, GlitchSnapCard } from './components/LabCards';

export default function InnovationLabSection({ section }) {
    const ref = useScrollReveal();

    const [offsetY, setOffsetY] = useState(0);
    useEffect(() => {
        const handleScroll = () => setOffsetY(window.scrollY * 0.1);
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    const blocks = [
        {
            id: 1,
            title: "DevTools CLI",
            desc: "Advanced terminal command line tools with real-time matrix decoding effects and system diagnostics.",
            visual: <TextDecodingCard icon=">_" title="SYSTEM_ROOT" subtitle="Accessing Mainframe..." delay={0} />,
            align: 'left',
            tags: ['System', 'CLI', 'Node.js']
        },
        {
            id: 2,
            title: "Physics Engine",
            desc: "Interactive web-based physics simulation allowing users to distort reality and manipulate gravity fields.",
            visual: <RealityDistortionCard icon="⚡" title="GRAVITY_WELL" subtitle="Distortion Field Active" delay={0} />,
            align: 'right',
            tags: ['WebGL', 'Physics', 'Interactive']
        },
        {
            id: 3,
            title: "Algorithmic Art",
            desc: "Generative visual gallery where chaos reconstructs into order through user interaction and algorithmic patterns.",
            visual: <GlitchSnapCard icon="👁️" title="NEURAL_NET" subtitle="Reconstructing Signal..." delay={0} image="assets/images/projects/card2.png" />,
            align: 'left',
            tags: ['Generative', 'Canvas', 'Art']
        }
    ];

    return (
        <div className="pd-section reveal theme-lab" ref={ref}>
            <div className="lab-grid-bg" style={{ backgroundPositionY: `${offsetY}px` }} />

            <div className="pd-section-centered-header" style={{ marginBottom: '4rem' }}>
                <span className="pd-section-badge" style={{ borderColor: 'var(--lab-accent)', color: 'var(--lab-accent)' }}>EXPERIMENTAL ZONE</span>
                <h3 className="lab-glitch" style={{ fontSize: '3.5rem', color: '#fff' }}>
                    <LoopingTypingText text="THE INNOVATION LAB" />
                </h3>
                <p style={{ fontFamily: 'monospace', color: 'var(--lab-accent)' }}>// [3] PROJECTS LOADED. SYSTEM READY.</p>
            </div>

            <div className="lab-blocks-container">
                {blocks.map((block, i) => (
                    <div key={i} className={`lab-project-block align-${block.align}`}>
                        <div className="lab-content-side">
                            <span className="lab-block-number">0{block.id}</span>
                            <h2 className="lab-block-title">{block.title}</h2>
                            <div className="lab-tags">
                                {block.tags.map((t, k) => <span key={k} className="lab-tag">{t}</span>)}
                            </div>
                            <p className="lab-block-desc">{block.desc}</p>
                            <div className="lab-actions">
                                <MagneticButton className="btn-lab-primary">VIEW SOURCE</MagneticButton>
                                <MagneticButton className="btn-lab-secondary">LIVE DEMO</MagneticButton>
                            </div>
                        </div>
                        <div className="lab-visual-side">
                            <LabVisualWrapper>
                                {block.visual}
                            </LabVisualWrapper>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}
