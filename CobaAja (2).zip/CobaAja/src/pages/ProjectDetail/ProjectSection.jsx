import { useScrollReveal } from '../../utils/hooks';
import MasonryGallery from '../../components/ui/MasonryGallery';
import { DesignFeatureCard } from '../../components/ui/FeatureCard';
import GridCard from '../../components/ui/GridCard';
import InnovationLabSection from '../InnovationLab/InnovationLabSection';

export default function ProjectSection({ section, index }) {
    const sRef = useScrollReveal();

    if (section.type === 'masonry-gallery') {
        return (
            <div className="pd-section reveal" ref={sRef}>
                <MasonryGallery section={section} />
            </div>
        );
    }

    if (section.type === 'design-gallery') {
        return (
            <div className="pd-section reveal" ref={sRef}>
                <div className="pd-section-centered-header">
                    <h3 className="pd-large-title">{section.title}</h3>
                </div>
                <div className="pd-features-grid stagger-children">
                    {section.items.map((item, j) => (
                        <DesignFeatureCard
                            key={j}
                            image={item.image}
                            title={item.title}
                            desc={item.desc}
                            delay={item.delay || j * 100}
                            accentColor={['#a29bfe', '#6c5ce7', '#00cec9', '#fd79a8'][j % 4]}
                            className={item.title === 'Personal Branding' ? 'pd-last-center' : ''}
                        />
                    ))}
                </div>
            </div>
        );
    }

    if (section.title === 'Desain Poster & UMKM') {
        return (
            <div className="pd-section reveal" ref={sRef}>
                <div className="pd-umkm-showcase">
                    <div className="pd-umkm-left">
                        <div className="pd-umkm-title-box">
                            <h1>DESAIN</h1>
                            <h2>DESAIN</h2>
                            <p>Desain Poster & UMKM</p>
                        </div>
                        <div className="pd-umkm-wide-img">
                            {/* First card (index 0) is the wide one */}
                            <img src={section.cards[0].image} alt="Wide Banner" />
                        </div>
                    </div>
                    {/* Next 3 cards are verticals */}
                    {section.cards.slice(1).map((card, j) => (
                        <div key={j} className="pd-umkm-vertical-img">
                            <img src={card.image} alt={`Design ${j + 1}`} />
                        </div>
                    ))}
                </div>
            </div>
        );
    }

    if (section.type === 'grid-cards') {
        return (
            <div className="pd-section reveal" ref={sRef}>
                <div className="pd-section-centered-header">
                    {section.badge && <span className="pd-section-badge">{section.badge}</span>}
                    <h3 className={['Review UI/UX Seabank'].includes(section.title) ? 'text-gradient-seabank' : ''}>{section.title}</h3>
                </div>
                <div className="pd-grid-cards">
                    {section.cards.map((card, j) => (
                        <GridCard key={j} card={card} index={j} />
                    ))}
                </div>
            </div>
        );
    }

    if (section.type === 'innovation-lab') {
        return <InnovationLabSection section={section} />;
    }

    return (
        <div className="pd-section reveal" ref={sRef}>
            <div className="pd-section-header">
                <span className="pd-section-number">{String(index + 3).padStart(2, '0')}</span>
                <h3>{section.title}</h3>
            </div>
            <div className="pd-section-divider" />
            {section.desc && <p className="pd-description">{section.desc}</p>}
            {section.items && (
                <div className="pd-items-list">
                    {section.items.map((item, j) => (
                        <div key={j} className="pd-item">
                            <span className="pd-item-bullet">▹</span>
                            <span>{item}</span>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}
