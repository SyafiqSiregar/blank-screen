import React, { useState, useEffect } from 'react';
import Navbar from '../../components/layout/Navbar';
import Footer from '../../components/layout/Footer';
import ScrollToTop from '../../components/layout/ScrollToTop';
import { useScrollReveal, useTilt } from '../../utils/hooks';
import LoopingTypingText from '../../components/ui/LoopingTypingText';
import LabDecorations from '../InnovationLab/components/LabDecorations';
import ScanlineOverlay from '../InnovationLab/components/ScanlineOverlay';
import CyberMeteorRain from '../InnovationLab/components/CyberMeteorRain';
import SystemKernelSection from '../InnovationLab/components/SystemKernelSection';
import ExperimentLogsSection from '../InnovationLab/components/ExperimentLogsSection';
import ProjectSection from './ProjectSection';

export default function ProjectDetail({ project, onBack }) {
    const [scrolled, setScrolled] = useState(false);
    const [showTop, setShowTop] = useState(false);

    useEffect(() => {
        window.scrollTo(0, 0);
        const handler = () => {
            setScrolled(window.scrollY > 50);
            setShowTop(window.scrollY > 400);
        };
        window.addEventListener('scroll', handler);
        return () => window.removeEventListener('scroll', handler);
    }, []);

    if (!project) return null;

    const headerRef = useScrollReveal();
    const imageRef = useScrollReveal();
    const aboutRef = useScrollReveal();
    const metaRef = useScrollReveal();
    const featuresRef = useScrollReveal();
    const resultsRef = useScrollReveal();
    const ctaRef = useScrollReveal();
    const tiltRef = useTilt();

    return (
        <div className="project-detail">
            <div className="pd-bg-glow pd-glow-1" />
            <div className="pd-bg-glow pd-glow-2" />

            <Navbar scrolled={scrolled} />
            <div className={`project-detail-container ${project.theme === 'lab' ? 'theme-lab' : ''}`}>

                {project.showDecorations && <LabDecorations />}
                {project.showScanner && <ScanlineOverlay />}
                {project.showMeteors && <CyberMeteorRain />}

                <button onClick={onBack} className="btn-secondary back-btn pd-back-btn">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 12H5" /><polyline points="12 19 5 12 12 5" /></svg>
                    Back to Home
                </button>

                {!project.hideHeader && (
                    <div className="pd-hero reveal" ref={headerRef}>
                        <div className="pd-tags">
                            {project.tags.map((tag, i) => (
                                <span key={i} className="pd-tag">{tag}</span>
                            ))}
                        </div>
                        <h1 className="pd-title">
                            {project.theme === 'lab' ? <LoopingTypingText text={project.title} /> : project.title}
                        </h1>
                        <p className="pd-subtitle">{project.desc}</p>
                    </div>
                )}

                {!project.hideCover && (
                    <div className={`pd-image-showcase reveal${project.image ? ' has-image' : ''}`} ref={imageRef}>
                        <div className="pd-image-wrapper tilt-card" ref={tiltRef}>
                            <div className="card-shine" />
                            {project.image ? <img src={project.image} alt={project.title} /> : <span className="pd-image-icon">{project.icon}</span>}
                        </div>
                    </div>
                )}

                {!project.hideMeta && (project.role || project.techStack) && (
                    <div className="pd-meta-section reveal" ref={metaRef}>
                        <div className="pd-meta-grid">
                            {project.role && (
                                <div className="pd-meta-card" style={{ animationDelay: '0ms' }}>
                                    <span className="pd-meta-badge">1</span>
                                    <div className="pd-meta-corner pd-corner-tl" />
                                    <div className="pd-meta-corner pd-corner-br" />
                                    <div className="pd-meta-icon">👤</div>
                                    <span className="pd-meta-label">My Role</span>
                                    <span className="pd-meta-value">{project.role}</span>
                                </div>
                            )}
                            <div className="pd-meta-connector">
                                <div className="pd-connector-line" />
                                <div className="pd-connector-dot" style={{ animationDelay: '0s' }} />
                                <div className="pd-connector-dot pd-dot-reverse" style={{ animationDelay: '1.5s' }} />
                            </div>
                            {project.techStack && (
                                <div className="pd-meta-card" style={{ animationDelay: '120ms' }}>
                                    <span className="pd-meta-badge">2</span>
                                    <div className="pd-meta-corner pd-corner-tl" />
                                    <div className="pd-meta-corner pd-corner-br" />
                                    <div className="pd-meta-icon">🛠️</div>
                                    <span className="pd-meta-label">Tech Stack</span>
                                    <span className="pd-meta-value">{project.techStack.join(', ')}</span>
                                </div>
                            )}
                            <div className="pd-meta-connector">
                                <div className="pd-connector-line" />
                                <div className="pd-connector-dot" style={{ animationDelay: '0.5s' }} />
                                <div className="pd-connector-dot pd-dot-reverse" style={{ animationDelay: '2s' }} />
                            </div>
                            {project.client && (
                                <div className="pd-meta-card" style={{ animationDelay: '240ms' }}>
                                    <span className="pd-meta-badge">3</span>
                                    <div className="pd-meta-corner pd-corner-tl" />
                                    <div className="pd-meta-corner pd-corner-br" />
                                    <div className="pd-meta-icon">🏢</div>
                                    <span className="pd-meta-label">Client</span>
                                    <span className="pd-meta-value">{project.client}</span>
                                </div>
                            )}
                            <div className="pd-meta-connector">
                                <div className="pd-connector-line" />
                                <div className="pd-connector-dot" style={{ animationDelay: '1s' }} />
                                <div className="pd-connector-dot pd-dot-reverse" style={{ animationDelay: '2.5s' }} />
                            </div>
                            {project.year && (
                                <div className="pd-meta-card" style={{ animationDelay: '360ms' }}>
                                    <span className="pd-meta-badge">4</span>
                                    <div className="pd-meta-corner pd-corner-tl" />
                                    <div className="pd-meta-corner pd-corner-br" />
                                    <div className="pd-meta-icon">📅</div>
                                    <span className="pd-meta-label">Year</span>
                                    <span className="pd-meta-value">{project.year}</span>
                                </div>
                            )}
                        </div>
                        {/* Floating particles */}
                        <div className="pd-meta-particles">
                            <div className="pd-particle" style={{ left: '10%', animationDelay: '0s', animationDuration: '4s' }} />
                            <div className="pd-particle" style={{ left: '30%', animationDelay: '1s', animationDuration: '5s' }} />
                            <div className="pd-particle" style={{ left: '55%', animationDelay: '2s', animationDuration: '3.5s' }} />
                            <div className="pd-particle" style={{ left: '75%', animationDelay: '0.5s', animationDuration: '4.5s' }} />
                            <div className="pd-particle" style={{ left: '90%', animationDelay: '1.5s', animationDuration: '3s' }} />
                            <div className="pd-particle pd-particle-teal" style={{ left: '20%', animationDelay: '2.5s', animationDuration: '5s' }} />
                            <div className="pd-particle pd-particle-teal" style={{ left: '65%', animationDelay: '0.8s', animationDuration: '4s' }} />
                            <div className="pd-particle pd-particle-teal" style={{ left: '85%', animationDelay: '1.8s', animationDuration: '3.5s' }} />
                        </div>
                    </div>
                )}

                {project.fullDesc && (
                    <div className="pd-section reveal" ref={aboutRef}>
                        <div className="pd-section-header">
                            <span className="pd-section-number">01</span>
                            <h3>About the Project</h3>
                        </div>
                        <div className="pd-section-divider" />
                        <p className="pd-description">{project.fullDesc}</p>
                    </div>
                )}

                {project.features && (
                    <div className="pd-section reveal" ref={featuresRef}>
                        <div className="pd-section-header">
                            <span className="pd-section-number">02</span>
                            <h3>Key Features</h3>
                        </div>
                        <div className="pd-section-divider" />
                        <div className="pd-features-grid">
                            {project.features.map((f, i) => (
                                <div key={i} className="pd-feature-card" style={{ animationDelay: `${i * 100}ms` }}>
                                    <div className="pd-feature-icon-wrap">
                                        <span>{f.icon}</span>
                                    </div>
                                    <strong>{f.title}</strong>
                                    <p>{f.desc}</p>
                                    <div className="pd-feature-glow" />
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {project.sections && project.sections.map((section, i) => (
                    <ProjectSection key={i} section={section} index={i} />
                ))}

                {project.showKernel && <SystemKernelSection />}

                {project.showLogs ? (
                    <ExperimentLogsSection logs={project.logs} />
                ) : (
                    project.results && (
                        <div className="pd-section pd-results-section reveal" ref={resultsRef}>
                            <div className="pd-section-header">
                                <span className="pd-section-number">{String((project.sections?.length || 0) + 3).padStart(2, '0')}</span>
                                <h3>Results & Impact</h3>
                            </div>
                            <div className="pd-section-divider" />
                            <div className="pd-results-grid">
                                {project.results.map((r, i) => (
                                    <div key={i} className="pd-result-item">
                                        <span className="pd-result-check">✓</span>
                                        <span>{r}</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )
                )}

                {project.showHoloCTA ? (
                    <HoloCTASection onBack={onBack} />
                ) : (
                    <div className="pd-bottom-cta reveal" ref={ctaRef}>
                        <p>Interested in this project?</p>
                        <div className="pd-bottom-actions">
                            {project.liveUrl && (
                                <a href={project.liveUrl} target="_blank" rel="noopener noreferrer" className="btn-primary magic-hover pd-live-btn">
                                    <span className="btn-text">🌐 Visit Site</span>
                                </a>
                            )}
                            <button onClick={onBack} className="btn-secondary">← View More Projects</button>
                        </div>
                    </div>
                )}
            </div>
            <Footer />
            <ScrollToTop visible={showTop} />
        </div>
    );
}
