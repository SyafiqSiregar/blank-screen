import { useEffect, useRef } from 'react';
import * as THREE from 'three';

export default function ThreeParticles() {
    const mountRef = useRef(null);
    useEffect(() => {
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        if (mountRef.current) mountRef.current.appendChild(renderer.domElement);

        // Particles
        const particleCount = 800;
        const geo = new THREE.BufferGeometry();
        const positions = new Float32Array(particleCount * 3);
        const colors = new Float32Array(particleCount * 3);
        const sizes = new Float32Array(particleCount);
        const palette = [
            [0.424, 0.361, 0.906], // #6c5ce7
            [0.635, 0.608, 0.996], // #a29bfe
            [0.992, 0.475, 0.659], // #fd79a8
            [0.0, 0.808, 0.788],   // #00cec9
        ];
        for (let i = 0; i < particleCount; i++) {
            positions[i * 3] = (Math.random() - 0.5) * 20;
            positions[i * 3 + 1] = (Math.random() - 0.5) * 20;
            positions[i * 3 + 2] = (Math.random() - 0.5) * 20;
            const c = palette[Math.floor(Math.random() * palette.length)];
            colors[i * 3] = c[0]; colors[i * 3 + 1] = c[1]; colors[i * 3 + 2] = c[2];
            sizes[i] = Math.random() * 3 + 1;
        }
        geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
        geo.setAttribute('size', new THREE.BufferAttribute(sizes, 1));

        const mat = new THREE.PointsMaterial({ size: 0.05, vertexColors: true, transparent: true, opacity: 0.7, sizeAttenuation: true, blending: THREE.AdditiveBlending });
        const points = new THREE.Points(geo, mat);
        scene.add(points);

        // Lines between nearby particles
        const lineMat = new THREE.LineBasicMaterial({ color: 0x6c5ce7, transparent: true, opacity: 0.06 });
        const lineGeo = new THREE.BufferGeometry();
        const linePositions = [];
        for (let i = 0; i < Math.min(particleCount, 200); i++) {
            for (let j = i + 1; j < Math.min(particleCount, 200); j++) {
                const dx = positions[i * 3] - positions[j * 3];
                const dy = positions[i * 3 + 1] - positions[j * 3 + 1];
                const dz = positions[i * 3 + 2] - positions[j * 3 + 2];
                if (Math.sqrt(dx * dx + dy * dy + dz * dz) < 2.5) {
                    linePositions.push(positions[i * 3], positions[i * 3 + 1], positions[i * 3 + 2]);
                    linePositions.push(positions[j * 3], positions[j * 3 + 1], positions[j * 3 + 2]);
                }
            }
        }
        lineGeo.setAttribute('position', new THREE.Float32BufferAttribute(linePositions, 3));
        const lines = new THREE.LineSegments(lineGeo, lineMat);
        scene.add(lines);

        camera.position.z = 8;
        let mouseX = 0, mouseY = 0;
        const onMouseMove = (e) => {
            mouseX = (e.clientX / window.innerWidth - 0.5) * 2;
            mouseY = (e.clientY / window.innerHeight - 0.5) * 2;
        };
        window.addEventListener('mousemove', onMouseMove);

        let frame;
        const animate = () => {
            frame = requestAnimationFrame(animate);
            points.rotation.x += 0.0005;
            points.rotation.y += 0.0008;
            lines.rotation.x = points.rotation.x;
            lines.rotation.y = points.rotation.y;
            camera.position.x += (mouseX * 1.5 - camera.position.x) * 0.02;
            camera.position.y += (-mouseY * 1.5 - camera.position.y) * 0.02;
            camera.lookAt(scene.position);

            // Scroll-based depth
            const scrollFactor = window.scrollY * 0.001;
            camera.position.z = 8 + scrollFactor * 3;
            points.rotation.z = scrollFactor * 0.5;

            renderer.render(scene, camera);
        };
        animate();

        const onResize = () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        };
        window.addEventListener('resize', onResize);

        return () => {
            cancelAnimationFrame(frame);
            window.removeEventListener('mousemove', onMouseMove);
            window.removeEventListener('resize', onResize);
            if (mountRef.current && renderer.domElement) mountRef.current.removeChild(renderer.domElement);
            renderer.dispose();
        };
    }, []);
    return <div id="three-canvas" ref={mountRef} />;
}
