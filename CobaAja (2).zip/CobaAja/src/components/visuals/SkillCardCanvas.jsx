import { useEffect, useRef } from 'react';

export default function SkillCardCanvas({ type }) {
    const canvasRef = useRef(null);
    const hoveredRef = useRef(false);
    const mouseRef = useRef({ x: 0.5, y: 0.5 });

    useEffect(() => {
        const cvs = canvasRef.current;
        if (!cvs) return;
        const ctx = cvs.getContext('2d');
        let frame;
        let t = 0;
        const dpr = Math.min(window.devicePixelRatio || 1, 2);

        const resize = () => {
            const rect = cvs.parentElement.getBoundingClientRect();
            cvs.width = rect.width * dpr;
            cvs.height = rect.height * dpr;
            ctx.scale(dpr, dpr);
        };
        resize();

        // --- ANIMATION DEFINITIONS ---
        // 1. UI/UX Design: floating color palette circles
        const uiuxParticles = Array.from({ length: 18 }, () => ({
            x: Math.random(), y: Math.random(),
            r: Math.random() * 6 + 3,
            vx: (Math.random() - 0.5) * 0.003,
            vy: (Math.random() - 0.5) * 0.003,
            hue: Math.floor(Math.random() * 360),
            phase: Math.random() * Math.PI * 2,
        }));

        // 2. Web Dev: floating code symbols
        const codeSymbols = ['<', '/', '>', '{', '}', ';', '()', '[]', '/>', '< >', '&&', '=>'];
        const codeParticles = Array.from({ length: 14 }, () => ({
            x: Math.random(), y: Math.random() + 0.2,
            vy: -(Math.random() * 0.004 + 0.001),
            vx: (Math.random() - 0.5) * 0.001,
            symbol: codeSymbols[Math.floor(Math.random() * codeSymbols.length)],
            opacity: Math.random() * 0.4 + 0.1,
            size: Math.random() * 6 + 8,
            phase: Math.random() * Math.PI * 2,
        }));

        // 3. Software Engineering: rotating gears
        const gears = [
            { x: 0.7, y: 0.35, r: 22, teeth: 8, speed: 0.008, dir: 1 },
            { x: 0.85, y: 0.6, r: 15, teeth: 6, speed: 0.012, dir: -1 },
            { x: 0.55, y: 0.7, r: 12, teeth: 5, speed: 0.015, dir: 1 },
        ];

        // 4. Graphic Design: animated bezier curves
        const curves = Array.from({ length: 5 }, (_, i) => ({
            phase: (i / 5) * Math.PI * 2,
            hue: [280, 320, 200, 160, 40][i],
            amplitude: Math.random() * 30 + 20,
        }));

        // 5. Mobile First: device outlines pulsing
        const devices = [
            { x: 0.65, y: 0.3, w: 22, h: 38, type: 'phone' },
            { x: 0.82, y: 0.55, w: 30, h: 22, type: 'tablet' },
            { x: 0.5, y: 0.7, w: 16, h: 28, type: 'phone' },
        ];

        // 6. Performance: speed streaks
        const streaks = Array.from({ length: 20 }, () => ({
            x: Math.random(), y: Math.random(),
            len: Math.random() * 30 + 10,
            speed: Math.random() * 0.015 + 0.005,
            opacity: Math.random() * 0.3 + 0.1,
            hue: Math.random() > 0.5 ? 270 : 170,
        }));

        function drawGear(ctx, cx, cy, outerR, innerR, teeth, angle, color) {
            ctx.beginPath();
            const step = (Math.PI * 2) / teeth;
            for (let i = 0; i < teeth; i++) {
                const a1 = angle + i * step;
                const a2 = a1 + step * 0.35;
                const a3 = a2 + step * 0.15;
                const a4 = a3 + step * 0.35;
                ctx.lineTo(cx + Math.cos(a1) * innerR, cy + Math.sin(a1) * innerR);
                ctx.lineTo(cx + Math.cos(a2) * outerR, cy + Math.sin(a2) * outerR);
                ctx.lineTo(cx + Math.cos(a3) * outerR, cy + Math.sin(a3) * outerR);
                ctx.lineTo(cx + Math.cos(a4) * innerR, cy + Math.sin(a4) * innerR);
            }
            ctx.closePath();
            ctx.strokeStyle = color;
            ctx.lineWidth = 1.5;
            ctx.stroke();
            // Center circle
            ctx.beginPath();
            ctx.arc(cx, cy, innerR * 0.35, 0, Math.PI * 2);
            ctx.stroke();
        }

        const animate = () => {
            const w = cvs.width / dpr;
            const h = cvs.height / dpr;
            ctx.clearRect(0, 0, w, h);
            const speed = hoveredRef.current ? 2.5 : 1;
            const alpha = hoveredRef.current ? 1.0 : 0.6;
            const mx = mouseRef.current.x;
            const my = mouseRef.current.y; // Corrected from mouseRef.y
            t += 0.016 * speed;

            if (type === 'uiux') {
                uiuxParticles.forEach(p => {
                    p.x += p.vx * speed;
                    p.y += p.vy * speed;
                    if (p.x < 0 || p.x > 1) p.vx *= -1;
                    if (p.y < 0 || p.y > 1) p.vy *= -1;
                    p.hue = (p.hue + 0.3 * speed) % 360;
                    const pulse = Math.sin(t * 2 + p.phase) * 0.3 + 1;
                    const px = p.x * w;
                    const py = p.y * h;
                    const grad = ctx.createRadialGradient(px, py, 0, px, py, p.r * pulse * 2);
                    grad.addColorStop(0, `hsla(${p.hue}, 80%, 65%, ${0.35 * alpha})`);
                    grad.addColorStop(1, `hsla(${p.hue}, 80%, 65%, 0)`);
                    ctx.beginPath();
                    ctx.arc(px, py, p.r * pulse * 2, 0, Math.PI * 2);
                    ctx.fillStyle = grad;
                    ctx.fill();
                    ctx.beginPath();
                    ctx.arc(px, py, p.r * pulse * 0.7, 0, Math.PI * 2);
                    ctx.fillStyle = `hsla(${p.hue}, 90%, 70%, ${0.5 * alpha})`;
                    ctx.fill();
                });
                // Connection lines between close particles
                for (let i = 0; i < uiuxParticles.length; i++) {
                    for (let j = i + 1; j < uiuxParticles.length; j++) {
                        const dx = (uiuxParticles[i].x - uiuxParticles[j].x) * w;
                        const dy = (uiuxParticles[i].y - uiuxParticles[j].y) * h;
                        const dist = Math.sqrt(dx * dx + dy * dy);
                        if (dist < 60) {
                            ctx.beginPath();
                            ctx.moveTo(uiuxParticles[i].x * w, uiuxParticles[i].y * h);
                            ctx.lineTo(uiuxParticles[j].x * w, uiuxParticles[j].y * h);
                            ctx.strokeStyle = `rgba(162, 155, 254, ${(1 - dist / 60) * 0.15 * alpha})`;
                            ctx.lineWidth = 0.5;
                            ctx.stroke();
                        }
                    }
                }
            }

            else if (type === 'webdev') {
                codeParticles.forEach(p => {
                    p.y += p.vy * speed;
                    p.x += Math.sin(t * 3 + p.phase) * 0.001;
                    if (p.y < -0.1) { p.y = 1.1; p.x = Math.random(); }
                    const float = Math.sin(t * 2 + p.phase) * 3;
                    const px = p.x * w;
                    const py = p.y * h + float;
                    ctx.font = `${p.size}px 'Space Grotesk', monospace`;
                    ctx.fillStyle = `rgba(162, 155, 254, ${p.opacity * alpha})`;
                    ctx.textAlign = 'center';
                    ctx.fillText(p.symbol, px, py);
                });
                // Floating cursor blink effect
                const cursorX = 0.3 * w + Math.sin(t) * 10;
                const cursorY = 0.5 * h + Math.cos(t * 1.3) * 8;
                if (Math.sin(t * 4) > 0) {
                    ctx.fillStyle = `rgba(253, 121, 168, ${0.4 * alpha})`;
                    ctx.fillRect(cursorX, cursorY - 8, 2, 16);
                }
            }

            else if (type === 'softeng') {
                gears.forEach(g => {
                    const cx = g.x * w;
                    const cy = g.y * h;
                    const angle = t * g.speed * 60 * g.dir;
                    const hoverScale = hoveredRef.current ? 1.15 : 1;
                    drawGear(ctx, cx, cy, g.r * hoverScale, g.r * 0.7 * hoverScale, g.teeth, angle, `rgba(108, 92, 231, ${0.3 * alpha})`);
                });
                // Dots connecting gears
                for (let i = 0; i < gears.length - 1; i++) {
                    ctx.beginPath();
                    ctx.setLineDash([3, 5]);
                    ctx.moveTo(gears[i].x * w, gears[i].y * h);
                    ctx.lineTo(gears[i + 1].x * w, gears[i + 1].y * h);
                    ctx.strokeStyle = `rgba(108, 92, 231, ${0.12 * alpha})`;
                    ctx.lineWidth = 1;
                    ctx.stroke();
                    ctx.setLineDash([]);
                }
                // Floating binary bits
                for (let i = 0; i < 8; i++) {
                    const bx = (0.1 + (i / 8) * 0.8) * w;
                    const by = (0.15 + Math.sin(t * 1.5 + i) * 0.05) * h;
                    ctx.font = '9px monospace';
                    ctx.fillStyle = `rgba(0, 206, 201, ${0.2 * alpha})`;
                    ctx.fillText(Math.sin(t + i * 2) > 0 ? '1' : '0', bx, by);
                }
            }

            else if (type === 'graphic') {
                curves.forEach((c, i) => {
                    ctx.beginPath();
                    const startX = 0;
                    const startY = (0.3 + i * 0.12) * h;
                    const cx = cvs.width / 2; // unused
                    ctx.moveTo(startX, startY);
                    for (let x = 0; x <= w; x += 2) {
                        const progress = x / w;
                        const y = startY +
                            Math.sin(progress * Math.PI * 2 + t * 2 + c.phase) * c.amplitude * (0.5 + mx * 0.5) +
                            Math.sin(progress * Math.PI * 4 + t * 1.3 + c.phase) * c.amplitude * 0.3;
                        ctx.lineTo(x, y);
                    }
                    const grad = ctx.createLinearGradient(0, 0, w, 0);
                    grad.addColorStop(0, `hsla(${c.hue}, 80%, 65%, 0)`);
                    grad.addColorStop(0.3, `hsla(${c.hue}, 80%, 65%, ${0.25 * alpha})`);
                    grad.addColorStop(0.7, `hsla(${c.hue}, 80%, 65%, ${0.25 * alpha})`);
                    grad.addColorStop(1, `hsla(${c.hue}, 80%, 65%, 0)`);
                    ctx.strokeStyle = grad;
                    ctx.lineWidth = 1.5;
                    ctx.stroke();
                });
                // Pen tool dots
                for (let i = 0; i < 4; i++) {
                    const dx = (0.2 + i * 0.2) * w;
                    const dy = (0.5 + Math.sin(t * 1.5 + i * 1.5) * 0.15) * h;
                    ctx.beginPath();
                    ctx.arc(dx, dy, 3, 0, Math.PI * 2);
                    ctx.fillStyle = `rgba(253, 121, 168, ${0.4 * alpha})`;
                    ctx.fill();
                    // Handles
                    ctx.beginPath();
                    ctx.moveTo(dx - 10, dy - 8 * Math.sin(t + i));
                    ctx.lineTo(dx, dy);
                    ctx.lineTo(dx + 10, dy + 8 * Math.cos(t + i));
                    ctx.strokeStyle = `rgba(253, 121, 168, ${0.2 * alpha})`;
                    ctx.lineWidth = 0.8;
                    ctx.stroke();
                }
            }

            else if (type === 'mobile') {
                devices.forEach((d, i) => {
                    const cx = d.x * w;
                    const cy = d.y * h;
                    const pulse = 1 + Math.sin(t * 2 + i * 1.5) * 0.05;
                    const dw = d.w * pulse;
                    const dh = d.h * pulse;
                    // Device outline
                    ctx.beginPath();
                    const borderR = d.type === 'phone' ? 4 : 3;
                    ctx.roundRect(cx - dw / 2, cy - dh / 2, dw, dh, borderR);
                    ctx.strokeStyle = `rgba(0, 206, 201, ${0.3 * alpha})`;
                    ctx.lineWidth = 1.5;
                    ctx.stroke();
                    // Screen area
                    ctx.beginPath();
                    ctx.roundRect(cx - dw / 2 + 2, cy - dh / 2 + (d.type === 'phone' ? 5 : 3), dw - 4, dh - (d.type === 'phone' ? 10 : 6), 2);
                    ctx.fillStyle = `rgba(108, 92, 231, ${0.06 * alpha})`;
                    ctx.fill();
                    // Screen "content" lines
                    for (let l = 0; l < 3; l++) {
                        const lw = (dw - 10) * (0.5 + Math.sin(t * 1.5 + l + i) * 0.2);
                        const lx = cx - dw / 2 + 5;
                        const ly = cy - dh / 2 + (d.type === 'phone' ? 10 : 7) + l * 5;
                        ctx.fillStyle = `rgba(162, 155, 254, ${0.2 * alpha})`;
                        ctx.fillRect(lx, ly, lw, 2);
                    }
                });
                // Wifi/signal waves
                const sigX = 0.3 * w;
                const sigY = 0.25 * h;
                for (let i = 0; i < 3; i++) {
                    const r = 8 + i * 8;
                    const wave = Math.sin(t * 3 - i * 0.5);
                    if (wave > -0.3) {
                        ctx.beginPath();
                        ctx.arc(sigX, sigY, r, -Math.PI * 0.35, -Math.PI * 0.65, true);
                        ctx.strokeStyle = `rgba(0, 206, 201, ${(0.3 - i * 0.08) * alpha * (wave * 0.5 + 0.5)})`;
                        ctx.lineWidth = 1.5;
                        ctx.stroke();
                    }
                }
            }

            else if (type === 'performance') {
                streaks.forEach(s => {
                    s.x += s.speed * speed;
                    if (s.x > 1.2) { s.x = -0.1; s.y = Math.random(); s.opacity = Math.random() * 0.3 + 0.1; }
                    const sx = s.x * w;
                    const sy = s.y * h;
                    const grad = ctx.createLinearGradient(sx - s.len, sy, sx, sy);
                    grad.addColorStop(0, `hsla(${s.hue}, 80%, 65%, 0)`);
                    grad.addColorStop(1, `hsla(${s.hue}, 80%, 65%, ${s.opacity * alpha})`);
                    ctx.beginPath();
                    ctx.moveTo(sx - s.len, sy);
                    ctx.lineTo(sx, sy);
                    ctx.strokeStyle = grad;
                    ctx.lineWidth = 1.5;
                    ctx.stroke();
                    // Bright head
                    ctx.beginPath();
                    ctx.arc(sx, sy, 1.5, 0, Math.PI * 2);
                    ctx.fillStyle = `hsla(${s.hue}, 90%, 80%, ${s.opacity * 1.5 * alpha})`;
                    ctx.fill();
                });
                // Speed meter gauge
                const gaugeX = 0.2 * w;
                const gaugeY = 0.65 * h;
                const gaugeR = 18;
                ctx.beginPath();
                ctx.arc(gaugeX, gaugeY, gaugeR, Math.PI * 0.8, Math.PI * 2.2);
                ctx.strokeStyle = `rgba(108, 92, 231, ${0.2 * alpha})`;
                ctx.lineWidth = 2;
                ctx.stroke();
                // Needle
                const needleAngle = Math.PI * 0.8 + (Math.PI * 1.4) * (0.7 + Math.sin(t * 2) * 0.3);
                ctx.beginPath();
                ctx.moveTo(gaugeX, gaugeY);
                ctx.lineTo(gaugeX + Math.cos(needleAngle) * gaugeR * 0.85, gaugeY + Math.sin(needleAngle) * gaugeR * 0.85);
                ctx.strokeStyle = `rgba(253, 121, 168, ${0.5 * alpha})`;
                ctx.lineWidth = 1.5;
                ctx.stroke();
            }

            frame = requestAnimationFrame(animate);
        };

        frame = requestAnimationFrame(animate);
        const ro = new ResizeObserver(resize);
        ro.observe(cvs.parentElement);

        return () => {
            cancelAnimationFrame(frame);
            ro.disconnect();
        };
    }, [type]);

    const handleMouseEnter = () => { hoveredRef.current = true; };
    const handleMouseLeave = () => { hoveredRef.current = false; mouseRef.current = { x: 0.5, y: 0.5 }; };
    const handleMouseMove = (e) => {
        const rect = canvasRef.current?.parentElement?.getBoundingClientRect();
        if (rect) {
            mouseRef.current = {
                x: (e.clientX - rect.left) / rect.width,
                y: (e.clientY - rect.top) / rect.height,
            };
        }
    };

    return (
        <canvas
            ref={canvasRef}
            className="skill-canvas"
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
            onMouseMove={handleMouseMove}
        />
    );
}
