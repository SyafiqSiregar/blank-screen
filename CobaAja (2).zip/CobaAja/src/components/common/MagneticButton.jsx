import { useState } from 'react';

export default function MagneticButton({ children, className, onClick }) {
    const [style, setStyle] = useState({});

    const handleMouseMove = (e) => {
        const { clientX, clientY, currentTarget } = e;
        const { left, top, width, height } = currentTarget.getBoundingClientRect();
        const x = (clientX - (left + width / 2)) * 0.3;
        const y = (clientY - (top + height / 2)) * 0.3;
        setStyle({ transform: `translate(${x}px, ${y}px)` });
    };

    const handleMouseLeave = () => {
        setStyle({ transform: 'translate(0, 0)' });
    };

    return (
        <button
            className={`magnetic-btn ${className || ''}`}
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
            onClick={onClick}
            style={style}
        >
            <span className="btn-text">{children}</span>
            <div className="btn-fill" />
        </button>
    );
}
