import { useScrollReveal, useTilt } from '../../utils/hooks';
import SkillCardCanvas from '../visuals/SkillCardCanvas';
import FuturisticIcon from './FuturisticIcon';

export function FeatureCard({ icon, title, desc, floatIcon, animType, accentColor, delay }) {
    const rev = useScrollReveal();
    const tilt = useTilt();
    return (
        <div
            className="feature-card reveal tilt-card"
            ref={e => { rev.current = e; tilt.current = e; }}
            style={{ '--card-accent': accentColor, '--card-delay': delay + 'ms' }}
        >
            <div className="card-shine" />
            <SkillCardCanvas type={animType} />
            <div className="feature-card-content">
                <div className="float-element">{floatIcon}</div>
                <FuturisticIcon type={animType} accentColor={accentColor} />
                <h3>{title}</h3>
                <p>{desc}</p>
            </div>
            <div className="feature-card-glow" />
        </div>
    );
}

export function DesignFeatureCard({ image, title, desc, delay, accentColor, className }) {
    const rev = useScrollReveal();
    const tilt = useTilt();
    return (
        <div
            className={`feature-card reveal tilt-card design-feature-card ${className || ''}`}
            ref={e => { rev.current = e; tilt.current = e; }}
            style={{ '--card-accent': accentColor, '--card-delay': delay + 'ms' }}
        >
            <div className="card-shine" />
            <div className="design-image-wrapper">
                <img src={image || 'placeholder.png'} alt={title} loading="lazy" />
            </div>
            <div className="feature-card-content">
                <h3>{title}</h3>
                <p>{desc}</p>
            </div>
            <div className="feature-card-glow" />
        </div>
    );
}
