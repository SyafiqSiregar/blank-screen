export default function MasonryGallery({ section }) {
    // Horizontal scroll layout (Museum Style)
    // No JS calculation needed for lines anymore as requested for "Layout geser"

    return (
        <div className="pd-section pd-horizontal-gallery">
            <div className="pd-poster-header">
                <h3>{section.title}</h3>
                <p className="pd-poster-description">{section.description}</p>
            </div>

            <div className="gallery-container">
                <div className="gallery-track">
                    {section.images.map((src, i) => (
                        <div className="gallery-item" key={i}>
                            <img
                                src={src}
                                alt={`Poster ${i + 1}`}
                                loading="lazy"
                                className="gallery-img"
                            />
                        </div>
                    ))}
                </div>
                {/* Scroll Hint */}
                <div className="scroll-hint">
                    <span>← SCROLL TO EXPLORE →</span>
                </div>
            </div>
        </div>
    );
}
