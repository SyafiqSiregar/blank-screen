import { useState, useEffect } from 'react';

export default function TypingText({ texts, speed = 80, pause = 2000 }) {
    const [display, setDisplay] = useState('');
    const [idx, setIdx] = useState(0);
    const [charIdx, setCharIdx] = useState(0);
    const [deleting, setDeleting] = useState(false);
    useEffect(() => {
        const current = texts[idx];
        const timeout = setTimeout(() => {
            if (!deleting) {
                setDisplay(current.substring(0, charIdx + 1));
                if (charIdx + 1 === current.length) setTimeout(() => setDeleting(true), pause);
                else setCharIdx(charIdx + 1);
            } else {
                setDisplay(current.substring(0, charIdx));
                if (charIdx === 0) { setDeleting(false); setIdx((idx + 1) % texts.length); }
                else setCharIdx(charIdx - 1);
            }
        }, deleting ? speed / 2 : speed);
        return () => clearTimeout(timeout);
    }, [charIdx, deleting, idx, texts, speed, pause]);
    return <><span className="gradient-text">{display}</span><span className="typing-cursor" /></>;
}
