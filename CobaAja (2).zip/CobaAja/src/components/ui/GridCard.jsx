import { useScrollReveal, useTilt } from '../../utils/hooks';

export default function GridCard({ card, index }) {
    const ref = useScrollReveal();
    const tiltRef = useTilt({ max: 5, scale: 1.02 });

    return (
        <div
            className="pd-service-card reveal"
            style={{
                '--accent-color': card.color,
                transitionDelay: `${index * 50}ms`,
                padding: card.image ? '0' : '32px 24px', // Remove padding for image cards
                minHeight: card.image ? '300px' : 'auto', // Increase height for images
                display: 'flex',
                flexDirection: 'column'
            }}
            ref={(el) => {
                ref.current = el;
                tiltRef.current = el;
            }}
        >
            {card.image ? (
                <div style={{
                    width: '100%',
                    height: '100%',
                    flex: '1',
                    overflow: 'hidden',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    background: 'var(--card-bg)',
                    borderRadius: 'inherit'
                }}>
                    <img
                        src={card.image}
                        alt={card.title || 'Design'}
                        style={{
                            width: '100%',
                            height: '100%',
                            objectFit: 'cover', // Fill the card
                            display: 'block'
                        }}
                    />
                </div>
            ) : (
                <>
                    <div className="pd-service-icon-wrapper">
                        <span className="pd-service-icon">{card.icon}</span>
                    </div>
                    <h4 className="pd-service-title">{card.title}</h4>
                    <p className="pd-service-desc">{card.desc}</p>
                </>
            )}
        </div>
    );
}
