
export default function FuturisticIcon({ type, accentColor }) {
    const icons = {
        uiux: (
            <svg viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg">
                <defs>
                    <linearGradient id="uiux-g1" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#a29bfe" />
                        <stop offset="100%" stopColor="#6c5ce7" />
                    </linearGradient>
                    <linearGradient id="uiux-g2" x1="0%" y1="100%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#fd79a8" stopOpacity="0.6" />
                        <stop offset="100%" stopColor="#a29bfe" stopOpacity="0.8" />
                    </linearGradient>
                    <filter id="uiux-glow">
                        <feGaussianBlur stdDeviation="2" result="blur" />
                        <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
                    </filter>
                </defs>
                {/* Back panel */}
                <rect x="18" y="8" width="28" height="20" rx="3" fill="url(#uiux-g2)" opacity="0.5" transform="rotate(6 32 18)" />
                {/* Middle panel */}
                <rect x="14" y="12" width="28" height="20" rx="3" fill="url(#uiux-g1)" opacity="0.7" transform="rotate(-3 28 22)" />
                {/* Front panel */}
                <rect x="10" y="16" width="28" height="20" rx="3" fill="url(#uiux-g1)" stroke="rgba(255,255,255,0.3)" strokeWidth="0.5" />
                {/* UI elements on front panel */}
                <rect x="13" y="19" width="10" height="2" rx="1" fill="rgba(255,255,255,0.7)" />
                <rect x="13" y="23" width="22" height="1.5" rx="0.75" fill="rgba(255,255,255,0.3)" />
                <rect x="13" y="27" width="16" height="1.5" rx="0.75" fill="rgba(255,255,255,0.3)" />
                <rect x="13" y="31" width="8" height="3" rx="1.5" fill="#fd79a8" opacity="0.8" />
                {/* Color dots */}
                <circle cx="42" cy="42" r="4" fill="#fd79a8" filter="url(#uiux-glow)" opacity="0.9" />
                <circle cx="34" cy="44" r="3" fill="#a29bfe" filter="url(#uiux-glow)" opacity="0.8" />
                <circle cx="46" cy="36" r="2.5" fill="#00cec9" opacity="0.7" />
            </svg>
        ),
        webdev: (
            <svg viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg">
                <defs>
                    <linearGradient id="web-g1" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#6c5ce7" />
                        <stop offset="100%" stopColor="#a29bfe" />
                    </linearGradient>
                    <filter id="web-glow">
                        <feGaussianBlur stdDeviation="1.5" result="blur" />
                        <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
                    </filter>
                </defs>
                {/* Terminal window */}
                <rect x="6" y="10" width="44" height="36" rx="4" fill="rgba(18,18,26,0.9)" stroke="url(#web-g1)" strokeWidth="1.5" />
                {/* Title bar */}
                <rect x="6" y="10" width="44" height="8" rx="4" fill="url(#web-g1)" opacity="0.2" />
                <circle cx="12" cy="14" r="1.5" fill="#ff5f56" />
                <circle cx="17" cy="14" r="1.5" fill="#ffbd2e" />
                <circle cx="22" cy="14" r="1.5" fill="#27c93f" />
                {/* Code lines */}
                <text x="10" y="26" fontSize="7" fontFamily="monospace" fill="#6c5ce7" filter="url(#web-glow)">{'<'}</text>
                <text x="16" y="26" fontSize="7" fontFamily="monospace" fill="#a29bfe">div</text>
                <text x="28" y="26" fontSize="7" fontFamily="monospace" fill="#6c5ce7" filter="url(#web-glow)">{'>'}</text>
                <rect x="14" y="29" width="20" height="1.5" rx="0.75" fill="#00cec9" opacity="0.5" />
                <rect x="14" y="33" width="14" height="1.5" rx="0.75" fill="#fd79a8" opacity="0.4" />
                <text x="10" y="41" fontSize="7" fontFamily="monospace" fill="#6c5ce7" filter="url(#web-glow)">{'</'}</text>
                <text x="19" y="41" fontSize="7" fontFamily="monospace" fill="#a29bfe">div</text>
                <text x="31" y="41" fontSize="7" fontFamily="monospace" fill="#6c5ce7" filter="url(#web-glow)">{'>'}</text>
                {/* Blinking cursor */}
                <rect x="36" y="35" width="1.5" height="7" rx="0.5" fill="#a29bfe" opacity="0.8">
                    <animate attributeName="opacity" values="0.8;0.2;0.8" dur="1.2s" repeatCount="indefinite" />
                </rect>
            </svg>
        ),
        softeng: (
            <svg viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg">
                <defs>
                    <linearGradient id="eng-g1" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#00cec9" />
                        <stop offset="100%" stopColor="#6c5ce7" />
                    </linearGradient>
                    <filter id="eng-glow">
                        <feGaussianBlur stdDeviation="2" result="blur" />
                        <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
                    </filter>
                </defs>
                {/* Outer hexagon */}
                <polygon points="28,4 48,15 48,37 28,48 8,37 8,15" fill="none" stroke="url(#eng-g1)" strokeWidth="1.5" opacity="0.4" />
                {/* Inner hexagon */}
                <polygon points="28,10 42,18 42,34 28,42 14,34 14,18" fill="rgba(0,206,201,0.08)" stroke="url(#eng-g1)" strokeWidth="1" />
                {/* Circuit lines */}
                <line x1="28" y1="10" x2="28" y2="4" stroke="#00cec9" strokeWidth="1" opacity="0.5" />
                <line x1="42" y1="18" x2="48" y2="15" stroke="#00cec9" strokeWidth="1" opacity="0.5" />
                <line x1="42" y1="34" x2="48" y2="37" stroke="#00cec9" strokeWidth="1" opacity="0.5" />
                <line x1="14" y1="18" x2="8" y2="15" stroke="#6c5ce7" strokeWidth="1" opacity="0.5" />
                <line x1="14" y1="34" x2="8" y2="37" stroke="#6c5ce7" strokeWidth="1" opacity="0.5" />
                {/* Core circle */}
                <circle cx="28" cy="26" r="8" fill="rgba(0,206,201,0.15)" stroke="url(#eng-g1)" strokeWidth="1.5" filter="url(#eng-glow)" />
                {/* Gear teeth on core */}
                <circle cx="28" cy="26" r="5" fill="none" stroke="#00cec9" strokeWidth="0.8" strokeDasharray="3 2" opacity="0.6">
                    <animateTransform attributeName="transform" type="rotate" from="0 28 26" to="360 28 26" dur="8s" repeatCount="indefinite" />
                </circle>
                {/* Node dots */}
                <circle cx="28" cy="10" r="2" fill="#00cec9" filter="url(#eng-glow)" />
                <circle cx="42" cy="18" r="2" fill="#6c5ce7" filter="url(#eng-glow)" />
                <circle cx="42" cy="34" r="2" fill="#00cec9" filter="url(#eng-glow)" />
                <circle cx="28" cy="42" r="2" fill="#6c5ce7" filter="url(#eng-glow)" />
                <circle cx="14" cy="34" r="2" fill="#00cec9" filter="url(#eng-glow)" />
                <circle cx="14" cy="18" r="2" fill="#6c5ce7" filter="url(#eng-glow)" />
                {/* Center dot */}
                <circle cx="28" cy="26" r="2.5" fill="#00cec9" filter="url(#eng-glow)">
                    <animate attributeName="r" values="2.5;3.5;2.5" dur="2s" repeatCount="indefinite" />
                </circle>
            </svg>
        ),
        graphic: (
            <svg viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg">
                <defs>
                    <linearGradient id="gfx-g1" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#fd79a8" />
                        <stop offset="100%" stopColor="#a29bfe" />
                    </linearGradient>
                    <linearGradient id="gfx-g2" x1="100%" y1="0%" x2="0%" y2="100%">
                        <stop offset="0%" stopColor="#6c5ce7" stopOpacity="0.6" />
                        <stop offset="100%" stopColor="#fd79a8" stopOpacity="0.9" />
                    </linearGradient>
                    <filter id="gfx-glow">
                        <feGaussianBlur stdDeviation="2" result="blur" />
                        <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
                    </filter>
                </defs>
                {/* Diamond/prism shape */}
                <polygon points="28,4 46,26 28,48 10,26" fill="rgba(253,121,168,0.1)" stroke="url(#gfx-g1)" strokeWidth="1.5" />
                {/* Inner diamond */}
                <polygon points="28,12 40,26 28,40 16,26" fill="rgba(253,121,168,0.08)" stroke="url(#gfx-g2)" strokeWidth="1" opacity="0.7" />
                {/* Refraction lines */}
                <line x1="28" y1="4" x2="16" y2="26" stroke="#fd79a8" strokeWidth="0.5" opacity="0.3" />
                <line x1="28" y1="4" x2="40" y2="26" stroke="#a29bfe" strokeWidth="0.5" opacity="0.3" />
                <line x1="10" y1="26" x2="46" y2="26" stroke="url(#gfx-g1)" strokeWidth="0.5" opacity="0.4" />
                {/* Spectrum rays from prism */}
                <line x1="46" y1="26" x2="54" y2="18" stroke="#ff6b6b" strokeWidth="1" opacity="0.5" />
                <line x1="46" y1="26" x2="54" y2="22" stroke="#ffa502" strokeWidth="1" opacity="0.5" />
                <line x1="46" y1="26" x2="54" y2="26" stroke="#ffd93d" strokeWidth="1" opacity="0.5" />
                <line x1="46" y1="26" x2="54" y2="30" stroke="#6c5ce7" strokeWidth="1" opacity="0.5" />
                <line x1="46" y1="26" x2="54" y2="34" stroke="#a29bfe" strokeWidth="1" opacity="0.5" />
                {/* Center glow */}
                <circle cx="28" cy="26" r="4" fill="#fd79a8" filter="url(#gfx-glow)" opacity="0.6">
                    <animate attributeName="opacity" values="0.6;0.9;0.6" dur="2.5s" repeatCount="indefinite" />
                </circle>
                {/* Orbiting dot */}
                <circle cx="28" cy="14" r="1.5" fill="#a29bfe" filter="url(#gfx-glow)">
                    <animateTransform attributeName="transform" type="rotate" from="0 28 26" to="360 28 26" dur="6s" repeatCount="indefinite" />
                </circle>
            </svg>
        ),
        mobile: (
            <svg viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg">
                <defs>
                    <linearGradient id="mob-g1" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#00cec9" />
                        <stop offset="100%" stopColor="#6c5ce7" />
                    </linearGradient>
                    <filter id="mob-glow">
                        <feGaussianBlur stdDeviation="1.5" result="blur" />
                        <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
                    </filter>
                </defs>
                {/* Phone body */}
                <rect x="16" y="4" width="24" height="44" rx="4" fill="rgba(18,18,26,0.9)" stroke="url(#mob-g1)" strokeWidth="1.5" />
                {/* Screen */}
                <rect x="18" y="9" width="20" height="33" rx="2" fill="rgba(0,206,201,0.06)" />
                {/* Status bar */}
                <rect x="20" y="11" width="8" height="1" rx="0.5" fill="#00cec9" opacity="0.4" />
                <rect x="32" y="11" width="4" height="1" rx="0.5" fill="#6c5ce7" opacity="0.4" />
                {/* UI blocks on screen */}
                <rect x="20" y="15" width="16" height="6" rx="1.5" fill="url(#mob-g1)" opacity="0.25" />
                <rect x="20" y="23" width="7" height="7" rx="1.5" fill="rgba(253,121,168,0.2)" stroke="#fd79a8" strokeWidth="0.5" opacity="0.6" />
                <rect x="29" y="23" width="7" height="7" rx="1.5" fill="rgba(108,92,231,0.2)" stroke="#6c5ce7" strokeWidth="0.5" opacity="0.6" />
                <rect x="20" y="32" width="16" height="2" rx="1" fill="#a29bfe" opacity="0.3" />
                <rect x="20" y="36" width="12" height="2" rx="1" fill="#a29bfe" opacity="0.2" />
                {/* Home indicator */}
                <rect x="24" y="44" width="8" height="1.5" rx="0.75" fill="#00cec9" opacity="0.4" />
                {/* Floating notification badge */}
                <circle cx="42" cy="10" r="5" fill="rgba(253,121,168,0.15)" stroke="#fd79a8" strokeWidth="0.8" filter="url(#mob-glow)">
                    <animate attributeName="r" values="5;6;5" dur="2s" repeatCount="indefinite" />
                </circle>
                <text x="42" y="12" fontSize="6" fill="#fd79a8" textAnchor="middle" fontWeight="bold">3</text>
                {/* Signal waves */}
                <path d="M8 20 Q4 16 8 12" stroke="#00cec9" strokeWidth="1" fill="none" opacity="0.4" />
                <path d="M6 22 Q0 16 6 10" stroke="#00cec9" strokeWidth="0.8" fill="none" opacity="0.25" />
            </svg>
        ),
        performance: (
            <svg viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg">
                <defs>
                    <linearGradient id="perf-g1" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#fd79a8" />
                        <stop offset="100%" stopColor="#6c5ce7" />
                    </linearGradient>
                    <linearGradient id="perf-g2" x1="0%" y1="0%" x2="0%" y2="100%">
                        <stop offset="0%" stopColor="#ffd93d" />
                        <stop offset="100%" stopColor="#fd79a8" />
                    </linearGradient>
                    <filter id="perf-glow">
                        <feGaussianBlur stdDeviation="2.5" result="blur" />
                        <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
                    </filter>
                </defs>
                {/* Lightning bolt */}
                <polygon points="30,2 18,24 26,24 22,50 40,22 31,22 36,2" fill="url(#perf-g2)" stroke="rgba(255,255,255,0.4)" strokeWidth="0.5" filter="url(#perf-glow)" />
                {/* Speed lines */}
                <line x1="4" y1="16" x2="14" y2="16" stroke="#fd79a8" strokeWidth="1.5" strokeLinecap="round" opacity="0.5">
                    <animate attributeName="opacity" values="0.5;0.1;0.5" dur="1s" repeatCount="indefinite" />
                </line>
                <line x1="2" y1="22" x2="16" y2="22" stroke="#a29bfe" strokeWidth="1" strokeLinecap="round" opacity="0.4">
                    <animate attributeName="opacity" values="0.4;0.1;0.4" dur="1.3s" repeatCount="indefinite" />
                </line>
                <line x1="6" y1="28" x2="18" y2="28" stroke="#6c5ce7" strokeWidth="1" strokeLinecap="round" opacity="0.35">
                    <animate attributeName="opacity" values="0.35;0.1;0.35" dur="0.8s" repeatCount="indefinite" />
                </line>
                <line x1="42" y1="30" x2="52" y2="30" stroke="#fd79a8" strokeWidth="1" strokeLinecap="round" opacity="0.35">
                    <animate attributeName="opacity" values="0.35;0.1;0.35" dur="1.1s" repeatCount="indefinite" />
                </line>
                <line x1="44" y1="36" x2="54" y2="36" stroke="#a29bfe" strokeWidth="1.5" strokeLinecap="round" opacity="0.4">
                    <animate attributeName="opacity" values="0.4;0.1;0.4" dur="0.9s" repeatCount="indefinite" />
                </line>
                {/* Energy ring */}
                <circle cx="30" cy="26" r="18" fill="none" stroke="url(#perf-g1)" strokeWidth="0.8" strokeDasharray="4 6" opacity="0.35">
                    <animateTransform attributeName="transform" type="rotate" from="0 30 26" to="360 30 26" dur="4s" repeatCount="indefinite" />
                </circle>
                {/* Spark dots */}
                <circle cx="14" cy="12" r="1.5" fill="#ffd93d" opacity="0.6">
                    <animate attributeName="opacity" values="0.6;0;0.6" dur="1.5s" repeatCount="indefinite" />
                </circle>
                <circle cx="46" cy="42" r="1.5" fill="#fd79a8" opacity="0.5">
                    <animate attributeName="opacity" values="0;0.5;0" dur="2s" repeatCount="indefinite" />
                </circle>
            </svg>
        ),
    };
    return (
        <div className="futuristic-icon-wrapper">
            <div className="futuristic-icon-inner" style={{ '--icon-accent': accentColor }}>
                {icons[type]}
            </div>
        </div>
    );
}
