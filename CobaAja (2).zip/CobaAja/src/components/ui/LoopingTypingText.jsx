import { useState, useEffect } from 'react';

export default function LoopingTypingText({ text }) {
    const [display, setDisplay] = useState('');
    const [phase, setPhase] = useState('typing'); // typing, pausing, deleting, waiting

    useEffect(() => {
        let timeout;

        if (phase === 'typing') {
            if (display.length < text.length) {
                timeout = setTimeout(() => {
                    setDisplay(text.slice(0, display.length + 1));
                }, 100);
            } else {
                setPhase('pausing');
            }
        } else if (phase === 'pausing') {
            timeout = setTimeout(() => {
                setPhase('deleting');
            }, 5000); // 5 seconds wait
        } else if (phase === 'deleting') {
            if (display.length > 0) {
                timeout = setTimeout(() => {
                    setDisplay(text.slice(0, display.length - 1));
                }, 50);
            } else {
                setPhase('waiting');
            }
        } else if (phase === 'waiting') {
            timeout = setTimeout(() => {
                setPhase('typing');
            }, 500);
        }

        return () => clearTimeout(timeout);
    }, [display, phase, text]);

    return (
        <span className="looping-typewriter">
            {display}
            <span className="term-cursor">_</span>
        </span>
    );
}
