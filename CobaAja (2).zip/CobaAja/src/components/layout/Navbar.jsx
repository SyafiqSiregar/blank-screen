import { useState } from 'react';

export default function Navbar({ scrolled }) {
    const [isOpen, setIsOpen] = useState(false);

    const scrollTo = (id) => {
        setIsOpen(false);
        const element = document.getElementById(id);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth' });
        }
    };

    return (
        <nav className={`navbar${scrolled ? ' scrolled' : ''}`}>
            <div className="container">
                <span className="logo" onClick={() => scrollTo('hero')}>Portofolio✦</span>

                <div className={`nav-elements ${isOpen ? 'active' : ''}`}>
                    <div className="nav-badge"><span className="dot" /> Available for Projects</div>
                    <ul className="nav-links">
                        <li><a onClick={() => scrollTo('features')}>Skills</a></li>
                        <li><a onClick={() => scrollTo('work')}>Work</a></li>
                        <li><a onClick={() => scrollTo('testimonials')}>Testimonials</a></li>
                        <li><a className="nav-cta" onClick={() => scrollTo('contact')}>Hire Me</a></li>
                    </ul>
                </div>

                <div className={`hamburger${isOpen ? ' active' : ''}`} onClick={() => setIsOpen(!isOpen)}>
                    <span className="bar"></span>
                    <span className="bar"></span>
                    <span className="bar"></span>
                </div>
            </div>
        </nav>
    );
}
