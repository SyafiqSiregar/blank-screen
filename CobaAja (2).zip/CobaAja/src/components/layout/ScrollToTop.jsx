export default function ScrollToTop({ visible }) {
    return (
        <button className={`scroll-top${visible ? ' visible' : ''}`}
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>↑</button>
    );
}
